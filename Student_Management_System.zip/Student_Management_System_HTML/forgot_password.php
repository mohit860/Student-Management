<?php 

/*
 * File Name- forgot_password.php
 * Date- 3-August-2021
 * Author- Mohit
 * Purpose- To forgot password.
 */




include 'header.php'; ?>
<?php require_once('header1.php');
 require_once ('includes/functions/send_email.php');
?>

<?php



$email ="";

if (isset($_POST['submit']) && $_POST['submit'] == 'Submit') {
       
       $first_name = "";
       $last_name = "";
       $email = mysqli_real_escape_string($con,$_POST['email']);
       $student_id = "";
       $errors = array();
       $reset_path = URL."password_reset.php?token=";
//       echo $reset_path."check";
        // Check the validation of the email
       
       if (empty($email)) {
            $errors[0] = "Please enter your email";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[0] = "Please enter valid email format";
        }
        else {
            $query = "Select sd_email from student_details where sd_email ='$email'";
            $result = mysqli_query($con, $query);
            if($result){
                if(mysqli_num_rows($result)==0){

                    $errors[0] = "Please enter registered id.";
                }
            }
            else{
                echo mysqli_error($con);
            }
        }
        
        // If there is no error then compose a mail and generate a token. Add the token in database. 
        
        if(count($errors)==0){
            $query1 = "Select sd_student_id, sd_email,sd_first_name, sd_last_name from student_details where sd_email ='$email'";
            $result1 = mysqli_query($con, $query1);
            if($result1){
                while($row = mysqli_fetch_array($result1)){
                    $fist_name = $row['sd_first_name'];
                    $last_name = $row['sd_last_name'];
                    $student_id = $row['sd_student_id'];
//                    print_r($row);
                 }
            }
            else{
                echo $query1." ".mysqli_error($con);
            }
//            echo $fist_name;
//            echo $last_name;
//            echo $student_id;
            
            // Generate the token for a particular email
            
            $token = substr(md5($email),0,8);
            $reset_path = $reset_path.$token;
            // Insert the token in the database.
            $query2 ="update student_details "
                    . "set sd_token = '$token' where sd_student_id = ".(int)$student_id ;
            
            $result2 = mysqli_query($con, $query2);
            if($result2){
               
               
        
            }
            else{
                echo $query2." ".mysqli_error($con);
            }
            
            // Now send the email.           
                      
                      
            $to = $email;
            $subject = "Forgot password Request at Velocity Software";
            $message = 'Hi'. ' '. $fist_name. ' '. $last_name.','.'<br>'.'<br>'.'Please click on below button to reset your password'.'<br>'.'<br>'.'<br>'.'<a href="'.$reset_path.'"'.'> <button > Please click here </button></a>' ;
//           

            send_mail($to,$subject,$message);
            $_SESSION['message'] = "Your Password reset mail has been sent.";
            $_SESSION['student_id'] = $student_id;
            header("Location:login.php");
        }
}      



?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">Find your email</h1>
<!--                 <?php if ( isset($result) and $result ==0) { ?>
                    <div style="text-align:center; color: #f00000;"><?php echo "please enter valid email/password"; ?></div>
                <?php } ?> -->
		<div class="signup-content">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3">
							<form id="sample" method="post" action="">
								<div class="form-group">
									<label>Enter your email Address <span class="color-danger">*</span></label>								
									<input type="text" id="email" name="email" class="form-control" value="<?php echo $email; ?>" data-rule-email="true"/>									
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors[0])) echo $errors[0]; ?></font></div>
                                                                </div>
								
					
								<div class="form-group">
									<input name = 'submit' type="submit" value="Submit" class="btn btn-green sign_in" >
								</div>								
							</form>
						</div>						
					</div>
				</div>
	</div>
</div>	
<?php include 'footer.php'; ?>
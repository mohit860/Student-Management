

<?php 
/*
 * File Name- index.php
 * Date- 30-July-2021
 * Author- Mohit
 * Purpose- To register and edit the details of the student.
 */

require_once 'includes/config.php';
?>

<?php require_once('header1.php'); ?>
<?php
//echo $_SESSION['sd_student_id'];
if (!isset($_SESSION['sd_student_id']) and isset($_GET['sid'])) {
    header("Location: login.php");
}
//echo "Hello World";

function check_date($date, $month, $year) {
    if($year<1950 && $year>2021){
        return false;
    }
    
    // block to check conditions for non-leap year  
    if ($year % 4 != 0) {   // checking for a non-leap year
        if ($month == 02) {  // checking for february
            if ($date >= 29 || $date <= 0) { // checking for valid dates in month of february of a non - leap year 
                return FALSE;
            } else {
                return TRUE;
            }
        }
        if ($month != 02) {
            switch ($month) {
                case '01':  // January
                case '03':// March
                case '05':// May
                case '07':// July
                case '08':// august
                case '10'://October
                case '12':// December 
                    if ($date <= 0 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11':// November
                    if ($date <= 0 || $date > 30) {  //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default : echo "month is" . $month;
            }
        }
    }

    // Block to check conditions for leap year -------------------------- 
    if ($year % 4 == 0 || $year % 400 == 0) {  // Checking for a leap year
        // check for february ---------------------------
        if ($month == 02) {
            if ($date > 29 || $date <= 00) {
                // Checking for valid dates in month of february
                return FALSE; //false
            } else {
                // return true
                return TRUE;
            }
        }
        // checking for other months------------------------
        if ($month != 02) {
            switch ($month) {
                case '01' :// January
                case '03' :// March
                case '05' :// May
                case '07' :// July
                case '08' :// August
                case '10' :// October
                case '12' :// December 
                    if ($date <= 00 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11' :// November
                    if ($date <= 00 || $date > 30) {   //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default :
            }
        }
        // check for leap year ended here----------------------------------------
    }
}
/* file upload variables
 * 
 */

//
// student details variables.
$first_name = "";
$last_name = "";
$date = "";
$email = "";
$password = "";
$confirm_password = "";
$contact_no = "";
$gender = "";
$address_line1 = "";
$city = "";
$pincode = "";
$state = "";
$country = "";
$Xboard = "";
$Xperc = "";
$Xyop = "";
$XIIboard = "";
$XIIperc = "";
$XIIyop = "";
$contact_no = "";
$hobbies = array();
$course = array();
$hobbies_text = "";
$country_name ="";
$flag = 0;
$file_name_time = "";
$document_add = "";
$fileTmpName ="";
$document_show =  "";
$sd_image = "";
if (isset($_GET['action']) && $_GET['action'] == 'Edit'){
    include 'header2.php';
    $flag+=1;
//    print_r($_GET);
     if(!empty($_GET['sid'])){
         // To find details of students.
        $query1 = "Select * from student_details where sd_student_id = ".(int)$_GET['sid'];
        $result = mysqli_query($con, $query1);
        if ($result) {
                $row = mysqli_fetch_assoc($result); 
                $first_name = $row['sd_first_name'];
                $last_name = $row['sd_last_name'];
                $date = $row['sd_dob'];
                $date = explode("-",$date);
                $date = $date[2]."/".$date[1]."/".$date[0];
//                echo $date;
                $email = $row['sd_email'];
                //$password = $row['sd_password'];
                //$confirm_password = $row['sd_password'];
                $contact_no = $row['sd_phone'];
                $gender = ucfirst($row['sd_gender']);
                $address_line1 = $row['sd_address'];
                $city = $row['sd_city'];
                $pincode = $row['sd_zip_code'];
                $state = $row['sd_state'];
                $country = $row['sd_country'];
               
                $country_name = $row['sd_country'];
                $course = $row['sd_applied_course'];
                $file_name_time = $row['sd_image'];
                $document_show = $row['sd_documents'];
                $hobbies = $row['sd_hobbies'];
//                $hobbies1 = $hobbies;
//                echo $date;
                $hobbies = explode(",",$hobbies);
                $sd_image = $row['sd_image'];
//                if (in_array("Others", $hobbies)){
//                    $pos = stripos($hobbies1,"Others");
//                    $hobbies_text = 
//                }
//                print_r($hobbies);
            
          
        }
        else{
            echo mysqli_error($con);
        }
        $query2 = "Select * from student_acedemic_details where sad_student_id = ".(int)$_GET['sid'];
        $result1 = mysqli_query($con, $query2);
        if ($result1) {
            while($row = mysqli_fetch_assoc($result1)){
//            print_r($row);
//            echo $row['sad_percentage'];
                if($row['sad_course_name']== 'XII'){
                    $XIIboard = $row['sad_board'];
                    $XIIperc = $row['sad_percentage'];
                    $XIIyop = $row['sad_year_of_passing'];

                }
                elseif ($row['sad_course_name']== 'X'){
                    $Xboard = $row['sad_board'];
                    $Xperc = $row['sad_percentage'];
                    $Xyop = $row['sad_year_of_passing'];
                }
            }
          
        }
        else{
            echo mysqli_error($con);
        }  
//        $query4 = "Select * from student_country where sc_country_name = '$country'";
//        $result4 = mysqli_query($con, $query4);
//        
//        if ($result4) {
//            $row = mysqli_fetch_assoc($result4);
//             $country = $row['sc_country_id'];
//        }
//        else{
//            echo mysqli_error($con);
//        }  
//        
        
     }
   
}
//print_r($_FILES);
$errors = array();
if (isset($_POST['submit']) && $_POST['submit'] == 'Submit') {
//    print_r($_FILES);
    
    
    
   
    
    
   
    //After form submit, this code will runs to add PHP validations(server side validations)
//    print_r($_POST);
    //$errors = array();
    $errors = array();
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $date = $_POST['date'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $contact_no = $_POST['contact_no'];
    $gender =isset($_POST['gender']) ? $_POST['gender'] : "";
    
//    $female = $_POST['female'];
    $address_line1 = $_POST['address_line1'];
    $city = strval($_POST['city']);
    $pincode = $_POST['pincode'];
    $state = strval($_POST['state']);
    $country = strval($_POST['country']);
    $Xboard = $_POST['Xboard'];
    $Xperc = $_POST['Xperc'];
    $Xyop = $_POST['Xyop'];
    $XIIboard = $_POST['XIIboard'];
    $XIIperc = $_POST['XIIperc'];
    $XIIyop = $_POST['XIIyop'];
    $hobbies = isset($_POST['hobbies']) ? $_POST['hobbies'] : array();
    $course = isset($_POST['course']) ? $_POST['course'] : "";
    $hobbies_text = $_POST['hobbies_text'];
    $success_msg = "Your details are successfully registered.";
    $country_id = (int)$country;
    $query6 = "Select * from student_country where sc_country_id = '$country_id'";
    $result6 = mysqli_query($con, $query6);

    if ($result6) {
        $row = mysqli_fetch_assoc($result6);
        $country_name = $row['sc_country_name'];
//        echo 'country_name'. $country_name;
    }
    else{
        echo mysqli_error($con);
    }  
    
//    //print_r($hobbies);
//    echo $gender;
    if (empty($first_name)) {
        $errors['firstname'] = "Error: Please enter your first name";
    } elseif (!ctype_alpha($first_name)) {
        $errors['firstname'] = "Please enter only alphabets";
    }
    
    if (empty($last_name)) {
        $errors['lastname'] = "Error: Please enter your last name";
    } elseif (!ctype_alpha($last_name)) {
        $errors['lastname'] = "Please enter only alphabets";
    }
    $date_explode = explode('/', $date);
	if(isset($date_explode[0])) {
		$day = $date_explode[0];
	} else {
		$day = '';
	}
	
	if(isset($date_explode[1])) {
		$month = $date_explode[1];
	} else {
		$month = '';
	}
	
	if(isset($date_explode[2])) {
		$year = $date_explode[2];
	} else {
		$year = '';
	}
    $arr = array($year,$month,$day);
    $date1 = implode("-",$arr);
    
    if (empty($date)) {
        $errors['date1'] = "Please Enter Date-of-birth";
    } elseif (!check_date($day,$month,$year)) {
        $errors['date1'] = "Please enter a valid date-of-birth";
    }
    
    if (empty($email)) {
        $errors['email'] = "Please enter your email";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format";
    } else {
        if(isset($_GET['action']) && $_GET['action']== 'Edit'){
          
        }
        else{
            $query = "Select * from student_details where sd_email ='$email'";
            $result = mysqli_query($con, $query);
            $num =mysqli_num_rows($result);
            if ($num > 0) {
                $errors['email'] = "This email id has already registered.";
            }  
        }
    }
    
    if(!isset($_GET['action']) ){
        if (empty($password)) {
            $errors['password'] = "Please enter your password";
        }
        if (empty($confirm_password)) {
            $errors['confirm_password'] = "Please re-enter your password";
        }else if($password != $confirm_password){
            $errors['confirm_password'] = "Please enter the same password";
        }
    }
    else{
        if($password != $confirm_password){
            $errors['confirm_password'] = "Please enter the same password";
        }
    }
    
    if (empty($contact_no)) {
        $errors['contact_no'] = "Please enter your mobile number";
    } elseif (strlen($contact_no) != 10) {//strlen - it will return the length of string
        $errors['contact_no'] = "Please enter a 10-digit mobile number";
    } elseif (!ctype_digit($contact_no)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['contact_no'] = "Error : Please enter only numbers";
    }
    
    if (empty($address_line1)) {
        $errors['address_line1'] = "Please enter the address";
    }
    if (empty($city)) {
        $errors['city'] = "Error: Please enter your city";//common function to recall error message from database
    } 
    if (empty($pincode)) {
        $errors['pincode'] = "Please enter your pincode";
    } elseif (!ctype_digit($pincode)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['pincode'] = "Error : Please enter only numbers";
    }
    if (empty($state)) {
        $errors['state'] = "Error: Please enter your state";
    }
    if (empty($country)) {
        $errors['country'] = "Error: Please enter your country";
    } 
    if (empty($Xboard)) {
        $errors['X-board'] = "Error: Please enter your board name";
    } elseif (!ctype_alpha($Xboard)) {
        $errors['X-board'] = "Please enter only alphabets";
    }
    if (empty($Xperc)) {
        $errors['X-perc'] = "Please enter your board percentage";
    } elseif (!ctype_digit($Xperc)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['X-perc'] = "Error : Please enter only numbers";
    }elseif(strlen($Xperc )!=2){
        $errors['X-perc'] = "Enter only two digit";
    }
    if (empty($Xyop)) {
        $errors['X-yop'] = "Please enter your X year of passing";
    } elseif (!ctype_digit($Xyop)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['X-yop'] = "Error : Please enter only numbers";
    }elseif(strlen($Xyop )!=4){
        $errors['X-yop'] = "Error: Please enter a valid year";
    }
    if (empty($XIIboard)) {
        $errors['XII-board'] = "Error: Please enter your board name";
    } elseif (!ctype_alpha($XIIboard)) {
        $errors['XII-board'] = "Please enter only alphabets";
    }
    if (empty($XIIperc)) {
        $errors['XII-perc'] = "Please enter your XII board percentage";
    } elseif (!ctype_digit($XIIperc)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['XII-perc'] = "Error : Please enter only numbers";
    }elseif(strlen($XIIperc )!=2){
        $errors['XII-perc'] = "Error: Please enter only two digit";
    }
    if (empty($XIIyop)) {
        $errors['XII-yop'] = "Please enter your year of passing";
    } elseif (!ctype_digit($XIIyop)) {//ctype_digit - it will check if the string contains all integer digit or not
        $errors['XII-yop'] = "Error : Please enter only numbers";
    }elseif(strlen($XIIyop )!=4){
        $errors['XII-yop'] = "Error: Please enter a valid year";
    }
    if (empty($hobbies)) {
        $errors['hobbies'] = "Please select your hobbies";
    }
    if (empty($course)) {
        $errors['course'] = "Please select your course";
    }
    if (isset($hobbies['Others']) && empty($hobbies_text)) {
        $errors[20] = "Please fill your other hobbies";
    }
    if (empty($gender)){
        
        $errors['gender'] = "Please select the gender";
//        echo $errors["gender"];
//        die;
        
    }
    if(isset($_FILES['the_file']['name']) && !empty($_FILES['the_file']['name'])){
        $uploadDirectory = FILE_PATH."/image/";
        $fileExtensionAllowed = ['jpeg','jpg','png'];
        $file_name = $_FILES['the_file']['name'];
        $file_size = $_FILES['the_file']['size'];
        $file_type = $_FILES['the_file']['type'];
        $fileTmpName = $_FILES['the_file']['tmp_name'];
        $file_name_time = time().$file_name;
    //    $file_size = $_FILES['the_file'][]
        $file_name_break = explode('.',$file_name);
        $file_end = $file_name_break[1];
        $uploadPath = $uploadDirectory . basename($file_name_time);
        if (!in_array($file_end, $fileExtensionAllowed)){
            $errors[22] = " This file extension is not allowed. Please upload a JPEG or PNG file";
        }
        if($file_size>2000000){
            $errors[22] = "File exceeds maximum size 2MB";
        }
    }
     if(isset($_FILES['document_file']['name'][0]) && !empty($_FILES['document_file']['name'][0])){    
//        echo 'document';
        $documentDirectory = FILE_PATH."/documents/";
        
        foreach($_FILES['document_file']['name'] as $key => $value){
            $document_name = $_FILES['document_file']['name'][$key];
            $documentExtensionAllowed = ['pdf','docx'];
            $document_size = $_FILES['document_file']['size'][$key];
            $document_type = $_FILES['document_file']['type'][$key];
            $documentTmpName = $_FILES['document_file']['tmp_name'][$key];
            $document_name_time = time().$document_name; 
//            echo $document_name_time."<br>";
            $document_name_break = explode('.',$document_name);
            $document_end = $document_name_break[1];
             if (!in_array($document_end, $documentExtensionAllowed)){
                $document_end ;
                $errors[24] = " This file extension is not allowed. Please upload a pdf or docx file";
            }
            echo $document_size;
            if($document_size>2000000){
                $errors[24] = "File exceeds maximum size 2MB";
            }
            
        }
       

     }
    
//    echo $errors[24];
    
    $errors = array_filter($errors);//This array_filter will remove any null key if found in array.
    if (count($errors) == 0) {
        $hash_password = md5($password);
        $hobbies_add = implode(",", $hobbies);
//         echo $country_name;
        // This section code is for update the entries.
        if(isset($_FILES['the_file']['name']) && !empty($_FILES['the_file']['name'])){
            $didupload = move_uploaded_file($fileTmpName, $uploadPath); // upload the profile picture on imgage folder.
        }  
//        echo $file_name_time;
            
            // uploading the multiple documents on document folder.
            
        if(isset($_FILES['document_file']['name'][0]) && !empty($_FILES['document_file']['name'][0])){
            foreach($_FILES['document_file']['name'] as $key => $value){
                $document_name = $_FILES['document_file']['name'][$key];
                $documentTmpName = $_FILES['document_file']['tmp_name'][$key];
                $document_name_time = time().$document_name;
                $document_add =  $document_name_time.",".$document_add;
            //    $file_size = $_FILES['the_file'][]
                $document_name_break = explode('.',$document_name);
                $document_end = $document_name_break[1];
                $uploadPath1 = $documentDirectory . basename($document_name_time);

                $didupload1 = move_uploaded_file($documentTmpName, $uploadPath1);
            }
        }
//
        if ($flag>0) {
//            echo 'update mode';
//            print_r($_GET);
            $document_update = $document_add.$document_show;
            
            if(!empty($_GET['sid'])){
                $query3 = "UPDATE student_details SET sd_first_name = '".addslashes($first_name)."', sd_last_name = '".addslashes($last_name)."', sd_dob = '$date1',sd_email = '$email', sd_password = '$hash_password', sd_phone = '".addslashes($contact_no)."' , sd_gender = '$gender' ,sd_address = '".addslashes($address_line1)."',sd_city = '".addslashes($city)."', sd_zip_code = '$pincode', sd_state = '$state', sd_hobbies = '$hobbies_add', sd_applied_course = '$course', sd_country = '$country_name',sd_documents = '$document_update' where sd_student_id = " . (int) $_GET['sid'];
                
                $result3 = mysqli_query($con, $query3);
                //echo mysql_num_rows($con);
                if ($result3) {
//                     echo "update successfully";
                } else {
                    echo mysqli_error($con);
                }
                $query5 = "UPDATE student_acedemic_details SET sad_board = '".addslashes($XIIboard)."',  sad_percentage = '$XIIperc', sad_year_of_passing = '$XIIyop' where sad_course_name = 'XII' and sad_student_id = " . (int) $_GET['sid'];
                $result5 = mysqli_query($con, $query5);
    //            echo mysql_num_rows($con);
                if ($result5) {
                    //echo "update successfully";
                } else {
                    echo mysqli_error($con);
                }
                $query6 = "UPDATE student_acedemic_details SET sad_board = '".addslashes($Xboard)."',  sad_percentage = '$Xperc', sad_year_of_passing = '$Xyop' where sad_course_name = 'X' and sad_student_id = " . (int) $_GET['sid'];
                $result6 = mysqli_query($con, $query6);
    //            echo mysql_num_rows($con);
                if ($result6) {
                    //echo "update successfully";
                } else {
                    echo mysqli_error($con);
                }
                
                

                
                
            }
        }elseif($flag==0) {
//           
            
            //INSERT INTO student

            $hash_password = md5(addslashes($password));
            $query2 = "INSERT INTO student_details ( sd_first_name, sd_last_name, sd_dob, sd_email,sd_password, sd_phone, sd_gender, sd_address, sd_city, sd_zip_code,sd_state, sd_country, sd_hobbies,sd_applied_course,sd_image,sd_documents)
                     VALUES ('".addslashes($first_name)."', '".addslashes($last_name)."', '".addslashes($date1)."', '$email', '$hash_password', '".addslashes($contact_no)."', '$gender','".addslashes($address_line1)."','".addslashes($city)."','".addslashes($pincode)."','".addslashes($state)."', '$country','$hobbies_add','$course','$file_name_time','$document_add');";

            $query3 = "select sd_student_id from student_details where sd_email = '$email'";
            if (mysqli_query($con, $query2)) {
                //echo "New record created successfully";
            } else {
                echo "Error: " . $query2 . "<br>" . mysqli_error($con);
            }
            $student_id = mysqli_query($con, $query3);
            $student_id_add = "";
            if ($student_id) {
                while ($row = mysqli_fetch_assoc($student_id)) {
                    $student_id_add = $row['sd_student_id'];
                    //            echo $student_id_add;
                }
                //echo "<br>";
            }
            //        $num =mysqli_num_rows($student_id);
            //        echo $num;
            //        print_r($student_id);
            $query4 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                       VALUES ( '$student_id_add','X', '".addslashes($Xboard)."','".addslashes($Xperc)."', '".addslashes($Xyop)."');";
            //        $student_academic = mysqli_query($con,$query4);
            if (mysqli_query($con, $query4)) {
                //echo "New record created successfully";
            } else {
                echo "Error: " . $query4 . "<br>" . mysqli_error($con);
            }
            $query5 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                       VALUES ( '$student_id_add','XII', '".addslashes($XIIboard)."','".addslashes($XIIperc)."','".addslashes($XIIyop)."');";
            //        $student_academic = mysqli_query($con,$query4);
            if (mysqli_query($con, $query5)) {
                //echo "New record created successfully";
            } else {
                echo "Error: " . $query5 . "<br>" . mysqli_error($con);
            }
          
        }else{
            $errors["common"] = "Something went wrong"; 
        }
        
    }
    else {
        $errors["common"] = "Please see below for errors";
    }
    if(isset($_POST['is_ajax']) && $_POST['is_ajax']==1){
            $response = array();
            if(count($errors)>0){
                $response['type'] = "error";
                $response["error"] = $errors;
                
            }else{
                  $response['type'] = "success";
            }
            
            echo json_encode($response);
            die;
        }

}


if (isset($_GET['action']) && $_GET['action'] == 'Edit'){
    //do nothing
}
else{
    include 'header.php';
}
?>

<div class="container">
	<div class="ManagementSystem">
                
		<h1 class="form-title">Student Management System</h1>
                <?php if (isset($errors) && count($errors) > 0) { ?>
                    <div style="text-align:center; color: #f00000;"><?php echo $errors["common"]; ?></div>
                <?php } ?> 
                  <div class="error"  id ="common_error" style="text-align:center; color: #f00000;"></div>
                  <div id ="success" style="text-align:center; color: green;"></div>
            
              
                 
                    <form id="sample" method="post" action="" enctype="multipart/form-data">
			<div class="row" >
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
				<div class="profile-pic">
					<div class="form-group">
                                            
						<label>Upload Image</label>
                                                <img id='img-upload' src="<?php if(!empty($sd_image)){ echo "uploads/image/$sd_image"; } else{ echo "images/user.png";}?>"/>
						<div class="input-group">
							<span class="input-group-btn">
								<span class="btn btn-default btn-file">
									Browseâ€¦ <input name= "the_file" type="file" id="imgInp">
                                                                        
                            
								</span>
                                                            
							</span>
							<input type="text" class="form-control" readonly>
                                                         
						</div>
                                                 <div><font color="#f00000" size="2px"><?php if(isset($errors[22])) echo $errors[22]; ?></font></div>
					
						<div class="form-group">
							<label>Upload Documents</label>
							<div class="box">
								<input name="document_file[]" multiple type="file"  id="file-1" class="inputfile inputfile-1" data-multiple-caption="{count} files selected"/>
								<label for="file-1"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg> <span>Choose a file&hellip;</span></label>
							</div>
						</div>	
                                                <div><font color="#f00000" size="2px"><?php if(isset($errors[24])) echo $errors[24]; ?></font></div>
                                                <?php 
                                                   
                                                    if (isset($_GET['action']) && $_GET['action'] == 'Edit'){
                                                        $documents = explode(",", $document_show);
                                                        $numbers = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", " ");
                                                        
//                                                       print_r( $documents);
                                                        foreach($documents as $key => $value11){$string = str_replace($numbers, '', $value11);  ?>
                                                            
                                                            </p><a href="download.php?file=<?php echo $value11;?>">  <?php echo $string; ?></a></p> 
                                                    <?php }
                                                    }
                                                ?>
					</div>
				</div>	
				</div>
                              
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <div  id="accordion">
                                      <h3>Basic Information</h3>
                                        <div>
                                            <div class="row">
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>First Name <span class="color-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="first_name" name="first_name" data-rule-firstname="true" value="<?php echo $first_name; ?>"/>
                                                                     <div><font color="#f00000" size="2px"><?php if(isset($errors['firstname'])) echo $errors['firstname']; ?></font></div>
                                                                      <font class="error" id="firstname_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>						
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Last Name <span class="color-danger">*</span></label>
                                                                    <input type="text" class="form-control" id="last_name" name="last_name" data-rule-lastname="true" value="<?php echo $last_name; ?>"/>
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['lastname'])) echo $errors['lastname']; ?></font></div>
                                                                     <font class="error" id="lastname_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                            </div>
                                            <div class="row">
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Date of Birth <span class="color-danger">*</span></label>
                                                                    <input placeholder="DD/MM/YYYY" type="text" class="form-control" id="date1" name="date" value="<?php echo $date; ?>" data-rule-requiredmmddyy="true"/>									
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['date1'])) echo $errors['date1']; ?></font></div>
                                                                      <font class="error" id="date1_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Email <span class="color-danger">*</span></label>
                                                                    <input type="text" id="email" name="email" class="form-control" value="<?php echo $email; ?>" data-rule-email="true"/>
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['email'])) echo $errors['email']; ?></font></div>
                                                                      <font class="error" id="email_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                            </div>
                                            <div class="row">
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Password <span class="color-danger">*</span></label>
                                                                    <input type="password" class="form-control" id="password" name="password" value="<?php echo $password?>" data-rule-passwd="true"/>
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['password'])) echo $errors['password']; ?></font></div>
                                                                     <font class="error" id="password_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Confirm Password <span class="color-danger">*</span></label>
                                                                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>"/>
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['confirm_password'])) echo $errors['confirm_password']; ?></font></div>
                                                                      <font class="error" id="confirm_password_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                            </div>
                                            <div class="row">
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Mobile Number <span class="color-danger">*</span></label>
                                                                    <input type="text" id="contact_no" name="contact_no" value="<?php echo $contact_no;  ?>" class="form-control" />
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['contact_no'])) echo $errors['contact_no']; ?></font></div>
                                                                       <font class="error" id="contact_no_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                    <label>Gender <span class="color-danger">*</span></label>
                                                                    <div class="gender_controls">
                                                                            <label class="radio-inline" for="gender-0">
                                                                              <input name="gender" id="gender-0" value="Male" type="radio" <?php if($gender == 'Male') echo 'checked';?>>
                                                                              Male
                                                                            </label>
                                                                            <label class="radio-inline" for="gender-1">
                                                                              <input name="gender" id="gender-1" value="Female" type="radio" <?php if($gender == 'Female') echo 'checked';?> >
                                                                              Female
                                                                            </label>
                                                                            <div><font color="#f00000" size="2px"><?php if(isset($errors['gender'])) echo $errors['gender']; ?></font></div>
                                                                      </div>
                                                                     <font class="error" id="gender_error" color="#f00000" size="2px"></font>
                                                            </div>
                                                    </div>
                                            </div>
                                      </div>  
                                      <h3>Residence Address</h3>
                                      <div>
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="form-group">
								<label>Address <span class="color-danger">*</span></label>
                                                                <textarea class="form-control" id="address_line1" name="address_line1" value=""><?php echo $address_line1; ?></textarea>
                                                                <div><font color="#f00000" size="2px"><?php if(isset($errors['address_line1'])) echo $errors['address_line1']; ?></font></div>
                                                                   <font class="error" id="address_line1_error" color="#f00000" size="2px"></font>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="form-group">
                                                                <label>City <span class="color-danger">*</span></label>
                                                                <select name= "city" id ="city"  class="form-control">
                                                                    <option value=""> Select state first</opton>
                                                                </select>
								
                                                                <div><font color="#f00000" size="2px"><?php if(isset($errors['city'])) echo $errors['city']; ?></font></div>
                                                                <font class="error" id="city_error" color="#f00000" size="2px"></font>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="form-group">
								<label>Zip Code<span class="color-danger">*</span></label>
								<input type="text" name="pincode" id="pincode" class="form-control" value="<?php echo $pincode; ?>" />
                                                                <div><font color="#f00000" size="2px"><?php if(isset($errors['pincode'])) echo $errors['pincode']; ?></font></div>
                                                                 <font class="error" id="pincode_error" color="#f00000" size="2px"></font>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="form-group">
                                                                <label>State <span class="color-danger">*</span></label>
                                                                <select name= "state" id ="state"  class="form-control">
                                                                    <option value=""> Select country first</opton>
                                                                </select>

                                                                <div><font color="#f00000" size="2px"><?php if(isset($errors['state'])) echo $errors['state']; ?></font></div>
                                                                 <font class="error" id="state_error" color="#f00000" size="2px"></font>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="form-group">
                                                                
								<label>Country <span class="color-danger">*</span></label>
                                                                <?php $query1 = "Select * from student_country";
                                                                 $country_table =  mysqli_query($con, $query1);
                                                                 
                                                                 ?>
                                                                 
								<select name="country" id="country"  class="form-control" >
									<option value="" selected="">(please select a country)</option>
                                                                         <?php if ($country_table) {
                                                                      
                                                                        while($row = mysqli_fetch_assoc($country_table)) { //echo $row["sc_country_name"]." ". $country; ?>
                                                                              <option value="<?php echo $row["sc_country_id"];?>"  <?php if($country == $row["sc_country_id"]) echo 'selected'; ?>  ><?php echo $row["sc_country_name"];?></option>  
                                                                              
                                                                              
                                                                         <?php }}mysqli_close($con); ?> 
                                                                       
                                                               
                                                            
                                                                       
								</select>
                                                                <div><font color="#f00000" size="2px"><?php if(isset($errors['country'])) echo $errors['country']; ?></font></div>
                                                                <font class="error" id="country_error" color="#f00000" size="2px"></font>
							</div>
						</div>						
					</div>
                                    </div>
                                        <h3>Qualification and hobbies </h3>
                                        <div>
					<div class="row">						
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="form-group">
								<label>Hobbies</label>
                                                                <?php $hobbies_add = implode(",",$hobbies);?>
								<div class="controls">
									<label class="checkbox-inline"><input type="checkbox" name= "hobbies[]" id="drawing" value="Drawing"<?php if (!empty($hobbies) &&in_array("Drawing", $hobbies)) echo 'checked'; ?>>Drawing</label>
									<label class="checkbox-inline"><input type="checkbox"  name= "hobbies[]" id="singing" value="Singing"<?php if (!empty($hobbies) &&in_array("Singing", $hobbies)) echo 'checked'; ?>>Singing</label>
									<label class="checkbox-inline"><input type="checkbox" name= "hobbies[]" id="dancing" value="Dancing"<?php if (!empty($hobbies) &&in_array("Dancing", $hobbies)) echo 'checked'; ?>>Dancing</label>
									<label class="checkbox-inline"><input type="checkbox" name= "hobbies[]" id="sketching" value="Sketching"<?php if (!empty($hobbies) &&in_array("Sketching", $hobbies)) echo 'checked'; ?>>Sketching</label>
									<label class="checkbox-inline"><input type="checkbox" name= "hobbies[]" id="others" value="Others"<?php if (!empty($hobbies) && in_array("Others", $hobbies)) echo 'checked'; ?>>Others</label>
                                                                        <label class="checkbox-inline"><input type="text" name="hobbies_text" id="text" class="form-control" value="<?php if (!empty($hobbies) && in_array("Others", $hobbies) && !empty($hobbies_text)) echo $hobbies_text; ?>"></label>
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors['hobbies'])) echo $errors['hobbies']; ?></font></div>
                                                                        <font class="error" id="hobbies_error" color="#f00000" size="2px"></font>
                                                                </div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="form-group">
								<label>Qualification</label>
								<div class="table-responsive">
									<table>
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th>Examination</th>
												<th>Board</th>
												<th>Percentage</th>
												<th>Year of Passing</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>Class X</td>
                                                                                                <td><input type="text" class="form-control" name="Xboard" id="X-board" value="<?php echo $Xboard; ?>"><div><font color="#f00000" size="2px"><?php if(isset($errors['X-board'])) echo $errors['X-board']; ?></font></div>  <font class="error" id="X-board_error" color="#f00000" size="2px"></font></td>
                                                                                                
												<td><input type="text" class="form-control" name="Xperc" id="X-perc" value="<?php echo $Xperc; ?>"><div><font color="#f00000" size="2px"><?php if(isset($errors['X-perc'])) echo $errors['X-perc']; ?></font></div><font class="error" id="X-perc_error" color="#f00000" size="2px"></font></td> 
                                                                                                <td><input type="text" class="form-control" name="Xyop" id="X-yop" value="<?php echo $Xyop; ?>"><div><font color="#f00000" size="2px"><?php if(isset($errors['X-yop'])) echo $errors['X-yop']; ?></font></div><font class="error" id="X-yop_error" color="#f00000" size="2px"></font></td>
											</tr>
											<tr>
												<td>2</td>
												<td>Class XII</td>
												<td><input type="text" class="form-control" name="XIIboard" id="XII-board" value="<?php echo $XIIboard; ?>"><div><font class="error" color="#f00000" size="2px"><?php if(isset($errors['XII-board'])) echo $errors['XII-board']; ?></font></div><font class="error" id="XII-board_error" color="#f00000" size="2px"></font></td>
												<td><input type="text" class="form-control" name="XIIperc" id="XII-perc" value="<?php echo $XIIperc; ?>"><div><font class="error" color="#f00000" size="2px"><?php if(isset($errors['XII-perc'])) echo $errors['XII-perc']; ?></font></div><font class="error" id="XII-perc_error" color="#f00000" size="2px"></font></td>
												<td><input type="text" class="form-control" name="XIIyop" id="XII-yop" value="<?php echo $XIIyop; ?>"><div><font class="error" color="#f00000" size="2px"><?php if(isset($errors['XII-yop'])) echo $errors['XII-yop']; ?></font></div><font class="error" id="XII-yop_error" color="#f00000" size="2px"></font></td>
											</tr>
											
										</tbody>
									</table>
								</div>
							</div>
						</div>		
					</div>	
					<div class="row">						
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="form-group">
								<label>Courses Applied for</label>
								<div class="controls">
									<label class="radio-inline" for="gender-0">
									  <input name="course" id="course-0" value="BCA" type="radio"<?php if (!empty($course) && $course =="BCA") echo 'checked'; ?>>
									  BCA
									</label>
									<label class="radio-inline" for="gender-1">
									  <input name="course" id="course-1" value="B.Tech" type="radio"<?php if (!empty($course) && $course =="B.Tech") echo 'checked'; ?>>
									  B.Tech
									</label>
									<label class="radio-inline" for="gender-1">
									  <input name="course" id="course-2" value="B.Sc" type="radio"<?php if (!empty($course) && $course =="B.Sc") echo 'checked'; ?>>
									  B.Sc
									</label>
									<label class="radio-inline" for="gender-1">
									  <input name="course" id="course-3" value="B.A" type="radio"<?php if (!empty($course) && $course =="B.A") echo 'checked'; ?>>
									  B.A
									</label>
                                                                    <div><font color="#f00000" size="2px"><?php if(isset($errors['course'])) echo $errors['course']; ?></font></div>
                                                                    <font class="error" id="course_error" color="#f00000" size="2px"></font>
								  </div>
							</div>
						</div>
					</div>
                                        </div>
                                        </div>	
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="action-button">
                                                                <input type="hidden" name="is_ajax" value="0" id="is_ajax">
                                                                <input type="hidden" name="submit" value="Submit" >
								<input name = "submit" type="submit" class="btn btn-green submit-form" value="Submit"  id="register"/>
								<input type="reset" class="btn btn-orange" value="Reset"/>
							</div>
						</div>
					</div>
				
                                </div>    
			</div>
		</form>
	</div>
</div>
<script>


function load_state(country_id,state_id){
            if(country_id){
                $.ajax({
                    type:'POST',
                    url:'ajax.php',
                    data:'country_id='+country_id,
                    async:false,
                    success:function(html){
                        $('#state').html(html);
                        $('#state').val(state_id); //This line selected the dropdown option.
                        $('#city').html('<option value="">Select state first</option>'); 
                    }
                }); 
            }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    }
    
    // This fuction is used to select the city in dropdown 
    function load_city(state_id,city_id){
            if(state_id){
                $.ajax({
                    type:'POST',
                    url:'ajax.php',
                    data:'state_id='+state_id,
                    success:function(html){
                        $('#city').html(html);
                        $('#city').val(city_id);
                         
                    }
                }); 
            }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    }
    // This fuction is used to select the state in dropdown
$(document).ready(function() {
    $( "#accordion" ).accordion({
        "animate":true,
        "collapsible": true
    });
    load_state("<?php echo $country; ?>","<?php echo $state;?>")
    
    load_city("<?php echo $state; ?>","<?php echo $city;?>")
    $('#country').on('change', function(){
            var countryID = $(this).val();
            load_state(countryID,"");

        });
        
         $('#state').on('change', function(){
            var stateID = $(this).val();
           load_city(stateID,"")

        });        
    
    
    $("#register").on("click", function(e) {
            e.preventDefault(); // prevent to reload the pagge
            $(".error").html("");
            $("#is_ajax").val("1");
            $.ajax({
                    url: 'index.php',
                    data: $("#sample").serialize(),
                    type: 'post',
                    dataType: 'json',
                    success: function(data) {
//                                        
                            if(data.type == "success") {
                                $("#success").html("Your registration is successfully completed.")
//                                          
                            } else if(data.type == "error") {

                                    $.each(data.error, function(index,value){
                                       console.log(index);
                                        $("#"+index+"_error").html(value);
                                    });

//						

                            }
                    }
            })
            return false;
    })

    });
    
</script>
<?php include 'footer.php'; ?>
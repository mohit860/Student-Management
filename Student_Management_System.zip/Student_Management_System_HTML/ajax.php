<?php
/* Name: Mohit
 * Date: 12-Aug-2021
 * file name: ajax.php
 * Purpose: To send the dropdown values of state and city.
 */

include 'header1.php';
// To create dropdown for state 
if(isset($_POST['country_id']) && !empty($_POST['country_id'])){
    $query = "select state_id,country_id, state_name from state where country_id = ".(int)$_POST['country_id'];
    $result = mysqli_query($con, $query);
    if(mysqli_num_rows($result)>0){ 
         $html = '';
        $html.= '<option value="">Select State</option>'; 
       
        while($row = mysqli_fetch_array($result)){ 
            
            $html.= '<option value="'.$row['state_id'].'">'.$row['state_name'].'</option>'; 
        } 
        echo $html;
    }else{ 
        echo '<option value="">State not available</option>'; 
    } 
  
  die;  
} 
// To create dropdown for city.
if (isset($_POST['state_id']) && !empty($_POST['state_id'])) {
    $query = "select city_id,state_id, city_name from city where state_id = " . (int) $_POST['state_id'];
    $result = mysqli_query($con, $query);
    if (mysqli_num_rows($result) > 0) {
        echo '<option value="">Select your city</option>';
        $html = "";
        while ($row = $result->fetch_assoc()) {
            echo '<option value="' . $row['city_id'] . '"' . (($row['city_id'] == $city) ? 'selected="selected"' : "") . '>' . $row['city_name'] . '</option>';
        }
    } else {
        echo '<option value="">city not available</option>';
    }
    die;
}








?>
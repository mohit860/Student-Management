<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Management System</title>
 
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/component.css">
  <link rel="stylesheet" href="css/bootstrap-datepicker3.css">
  
  
</head>
<body>
	<header>
		<div class="container">
			<div class="logo">
				<img src="images/logo.png"/>
			</div>
		</div>
	</header>
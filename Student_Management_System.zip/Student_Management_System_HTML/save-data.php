<?php include 'header.php'; ?>
<!--<form  method="post" action="" enctype="multipart/form-data">
  <label for="upload">Upload CSV file</label>
  <input name="the_file" type="file" id="fname" name="upload"><br>
  <label for="sub">Submit     </label>
  <input type="submit" id="lname" name="sub">
</form>-->

<?php

/*
 * File Name- index.php
 * Date- 1-August-2021
 * Author- Mohit
 * Purpose- To import the csv file..
 */
require_once('header1.php'); 
//echo $_SESSION['sd_email'];
if (!isset($_SESSION['sd_email'])) {
    header("Location: login.php");
}
    require_once 'includes/config.php';
//    include 'header1.php';
//    print_r($_FILES);
    
    function check_date($date, $month, $year) {
    if($year<1950 && $year>2021){
        return false;
    }
    
    // block to check conditions for non-leap year  
    if ($year % 4 != 0) {   // checking for a non-leap year
        if ($month == 02) {  // checking for february
            if ($date >= 29 || $date <= 0) { // checking for valid dates in month of february of a non - leap year 
                return FALSE;
            } else {
                return TRUE;
            }
        }
        if ($month != 02) {
            switch ($month) {
                case '01':  // January
                case '03':// March
                case '05':// May
                case '07':// July
                case '08':// august
                case '10'://October
                case '12':// December 
                    if ($date <= 0 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11':// November
                    if ($date <= 0 || $date > 30) {  //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default : echo "month is" . $month;
            }
        }
    }

    // Block to check conditions for leap year -------------------------- 
    if ($year % 4 == 0 || $year % 400 == 0) {  // Checking for a leap year
        // check for february ---------------------------
        if ($month == 02) {
            if ($date > 29 || $date <= 00) {
                // Checking for valid dates in month of february
                return FALSE; //false
            } else {
                // return true
                return TRUE;
            }
        }
        // checking for other months------------------------
        if ($month != 02) {
            switch ($month) {
                case '01' :// January
                case '03' :// March
                case '05' :// May
                case '07' :// July
                case '08' :// August
                case '10' :// October
                case '12' :// December 
                    if ($date <= 00 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11' :// November
                    if ($date <= 00 || $date > 30) {   //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default :
            }
        }
        // check for leap year ended here----------------------------------------
    }
}
    $table=0;
    $errors_final = array();
    $register = 0;
    $unregister =0;
    $student = array();
    if (isset($_FILES['the_file']['name']) && !empty($_FILES['the_file']['name'])) {
//               echo 1;
    $uploadDirectory = FILE_PATH . "/csv/";
    $fileExtensionAllowed = ['csv'];
    $file_name = $_FILES['the_file']['name'];
    $file_size = $_FILES['the_file']['size'];
    $file_type = $_FILES['the_file']['type'];
    $fileTmpName = $_FILES['the_file']['tmp_name'];
    $file_name_time = time() . $file_name;
    $file_name_break = explode('.', $file_name);
    $file_end = $file_name_break[1];
    $uploadPath = $uploadDirectory . basename($file_name_time);
    $didupload = move_uploaded_file($fileTmpName, $uploadPath);
//    $file_name;
//    echo $file_name;
    $file = fopen($uploadPath, "r");
    $file1 = fopen($uploadPath, "r");
//            print_r(fgetcsv($file));
    $error_row = 2;
    $errors_final = array();
    
    // this while loop for check the errors.
    
    while (($data1 = fgetcsv($file, 1000, ",")) !== FALSE) {
//            print_r($data);
                
                if ($data1[0] == 'Student_id') {
//                echo 3;
                } else {
                    $errors = array();
                    $student_id = $data1[0];
                    $first_name = $data1[1];
                    $last_name = $data1[2];
                    $date = $data1[3];
                    $email = $data1[4];
                    //                        $password =  $data[];
                    //                        $confirm_password =  $data[1];
                    $contact_no = $data1[5];
                    $gender = $data1[6];
                    $address_line1 = $data1[7];
                    $city = $data1[8];
                    $pincode = $data1[9];
                    $state = $data1[10];
                    $country = $data1[11];
                    $hobbies = $data1[12];
                    $course = $data1[13];
                    $Xboard = $data1[14];
                    $Xperc = $data1[15];
                    $Xyop = $data1[16];
                    $XIIboard = $data1[17];
                    $XIIperc = $data1[18];
                    $XIIyop = $data1[19];
//                        
//              
//                echo $query8 = "select sd_student_id "
//                        . "from student_details "
//                        . "where sd_student_id = " . (int) $data[0];
//                $result8 = mysqli_query($con, $query8);
//                if ($result8) {
//                    if (mysqli_num_row($result8) > 0) {
//                        
//                    } else {
//                        $errors[22] = "Please enter correct Student Id";
//                    }
//                }
//                else{
//                    echo mysqli_error($con);
//                }
                    if (empty($first_name)) {
                        $errors[0] = "Error: Please enter your first name";
                    } elseif (!ctype_alpha($first_name)) {
                        $errors[0] = "Please enter only alphabets in your first name";
                    }

                    if (empty($last_name)) {
                        $errors[1] = "Error: Please enter your last name";
                    } elseif (!ctype_alpha($last_name)) {
                        $errors[1] = "Please enter only alphabets in your last name";
                    }
//                        echo $date;
                    $date_explode = explode('/', $date);
                    if (isset($date_explode[0])) {
                        $day = $date_explode[0];
                    } else {
                        $day = '';
                    }

                    if (isset($date_explode[1])) {
                        $month = $date_explode[1];
                    } else {
                        $month = '';
                    }

                    if (isset($date_explode[2])) {
                        $year = $date_explode[2];
                    } else {
                        $year = '';
                    }
                    
                    $arr = array($year, $month, $day);
                    $date1 = implode("-", $arr);
//                        echo $date1;
                    if (empty($date)) {
                        $errors[2] = "Please Enter Date-of-birth";
                    } elseif (!check_date($day, $month, $year)) {
                        $errors[2] = "Please enter a valid date-of-birth";
                    }

                    if (empty($email)) {
                        $errors[3] = "Please enter your email";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $errors[3] = "Please enter valid email format";
                    } else {
                        $condition = "";
                        if (!empty($student_id) && (int) $student_id > 0) {
                            $condition .=" and  sd_student_id !=  " . (int) $student_id;
                        }
                        $query = "Select * from student_details where sd_email ='$email' $condition";
                        $result = mysqli_query($con, $query);
                        $num = mysqli_num_rows($result);
                        if ($num > 0) {
                            $errors[3] = "This email id has already registered.";
                        }
                    }

                    if (empty($contact_no)) {
                        $errors[6] = "Please enter your mobile number";
                    } elseif (strlen($contact_no) != 10) {//strlen - it will return the length of string
                        $errors[6] = "Please enter a 10-digit mobile number";
                    } elseif (!ctype_digit($contact_no)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[6] = "Error : Please enter only numbers in mobile number";
                    }

                    if (empty($address_line1)) {
                        $errors[7] = "Please enter the address";
                    }
                    if (empty($city)) {
                        $errors[8] = "Error: Please enter your city"; //common function to recall error message from database
                    } elseif (!ctype_alpha($city)) {
                        $errors[8] = "Please enter only alphabets in city";
                    }
                    if (empty($pincode)) {
                        $errors[9] = "Please enter your pincode";
                    } elseif (!ctype_digit($pincode)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[9] = "Error : Please enter only numbers in your pincode";
                    }
                    if (empty($state)) {
                        $errors[10] = "Error: Please enter your state"; //common function to recall error message from database
                    } elseif (!ctype_alpha($state)) {
                        $errors[10] = "Please enter only alphabets in your state";
                    }
                    if (empty($country)) {
                        $errors[11] = "Error: Please enter your country"; //common function to recall error message from database
                    } elseif (!ctype_alpha($state)) {
                        $errors[11] = "Please enter only alphabets in your country";
                    }

                    if (empty($Xboard)) {
                        $errors[12] = "Error: Please enter your board name";
                    } elseif (!ctype_alpha($Xboard)) {
                        $errors[12] = "Please enter only alphabets in your board name";
                    }
                    if (empty($Xperc)) {
                        $errors[13] = "Please enter your board percentage";
                    } elseif (!ctype_digit($Xperc)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[13] = "Error : Please enter only numbers in your board percentage";
                    } elseif (strlen($Xperc) != 2) {
                        $errors[13] = "Enter only two digit";
                    }
                    if (empty($Xyop)) {
                        $errors[14] = "Please enter your X year of passing";
                    } elseif (!ctype_digit($Xyop)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[14] = "Error : Please enter only numbers in passing year";
                    } elseif (strlen($Xyop) != 4) {
                        $errors[14] = "Error: Please enter a valid year for X";
                    }
                    if (empty($XIIboard)) {
                        $errors[15] = "Error: Please enter your board name";
                    } elseif (!ctype_alpha($XIIboard)) {
                        $errors[15] = "Please enter only alphabets in your XII board";
                    }
                    if (empty($XIIperc)) {
                        $errors[16] = "Please enter your XII board percentage";
                    } elseif (!ctype_digit($XIIperc)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[16] = "Error : Please enter only numbers in your XII percentage";
                    } elseif (strlen($XIIperc) != 2) {
                        $errors[16] = "Error: Please enter only two digit";
                    }
                    if (empty($XIIyop)) {
                        $errors[17] = "Please enter your year of passing";
                    } elseif (!ctype_digit($XIIyop)) {//ctype_digit - it will check if the string contains all integer digit or not
                        $errors[17] = "Error : Please enter only numbers in XII yop";
                    } elseif (strlen($XIIyop) != 4) {
                        $errors[17] = "Error: Please enter a valid year in XII yop";
                    }
                    if (empty($hobbies)) {
                        $errors[18] = "Please select your hobbies";
                    }
                    if (empty($course)) {
                        $errors[19] = "Please select your course";
                    }
                    if (isset($hobbies['Others']) && empty($hobbies_text)) {
                        $errors[20] = "Please fill your other hobbies";
                    }
                    if (empty($gender)) {

                        $error[21] = "Please select the gender";
                        //        echo $error[21];
                    }
                    if (count($errors) != 0) {
                        foreach ($errors as $key => $value) {
//                            echo "Row" . " " . $error_row . " " . $value . "<br>";
                        }
                         $errors_final[$error_row] = $errors;
                    }
                   
                    $error_row++;
                }
                
//            print_r($data);
     }
    $flag = 0;
  
//    print_r($errors);
    $student_id = "";
    $first_name = "";
    $last_name = "";
    $date = "";
    $email = "";
//                        $password =  $data[];
//                        $confirm_password =  $data[1];
    $contact_no = "";
    $gender = "";
    $address_line1 = "";
    $city = "";
    $pincode = "";
    $state = "";
    $country = "";
    $hobbies = "";
    $course = "";
    $Xboard = "";
    $Xperc = "";
    $Xyop = "";
    $XIIboard = "";
    $XIIperc = "";
    $XIIyop = "";
    $date1 = "";
    $flag = 0;
    $date1 ="";
//echo count($errors_final)."error";
if(count($errors_final)==0){
   
    // This while loop for enter the data.
    
    while (($data = fgetcsv($file1, 1000, ",")) !== FALSE) {
//        print_r($data);
        $table+=1;
        if ($data[0] == 'Student_id') {
            
        } else {
//            echo 4;
            $error_row = 2;
            $student_id = $data[0];
            $first_name = $data[1];
            $last_name = $data[2];
            $date = $data[3];
            $arr = explode("/",$date);
            $arr1 = array($arr[2],$arr[1],$arr[0]);
            $date1 = implode("-",$arr1);
            $email = $data[4];
//                        $password =  $data[];
//                        $confirm_password =  $data[1];
            $contact_no = $data[5];
            $gender = $data[6];
            $address_line1 = $data[7];
            $city = $data[8];
            $pincode = $data[9];
            $state = $data[10];
            $country = $data[11];
            $hobbies = $data[12];
            $course = $data[13];
            $Xboard = $data[14];
            $Xperc = $data[15];
            $Xyop = $data[16];
            $XIIboard = $data[17];
            $XIIperc = $data[18];
            $XIIyop = $data[19];
            
//            echo $Xboard;
            
//            print_r($data);
            if (count($errors) == 0) {
//                print_r($data);
//                echo "<br>";
//                echo $student_id;
               
//                print_r($student);
//                echo $address_line1;
                if (!empty($student_id) && (int) $student_id > 0) {
//                    echo "Data updation start";
//                                    echo $data[0]."check";
                    $student[] = array($student_id, $first_name, $last_name, $course, $email, $address_line1, $date, $gender);
                    $register+=1;
//                    echo $register . $student_id;
                    $query2 = "UPDATE student_details "
                            . "SET sd_first_name = '" . addslashes($first_name) . "', "
                            . "sd_last_name = '" . addslashes($last_name) . "',"
                            . " sd_email =  '$email',"
                            . "sd_phone = '$contact_no' ,"
                            . "sd_gender = '$gender', "
                            . "sd_address = '$address_line1', "
                            . "sd_city = '$city', "
                            . "sd_zip_code = '$pincode',"
                            . "sd_state = '$state',"
                            . "sd_country = '$country',"
                            . "sd_hobbies= '$hobbies', "
                            . "sd_applied_course = '$course', "
                            . "sd_dob = '$date1' "
                            . "where sd_student_id = " . (int) $student_id;
                    $result2 = mysqli_query($con, $query2);

                    //                                 echo mysqli_num_rows($result12);
                    if ($result2) {
//                        echo "student detail Data updated";
                    } else {
                        mysqli_error($con);
                        //                                     echo "no run";
                    }

                    $query3 = "UPDATE student_acedemic_details "
                            . "SET sad_board = '" . addslashes($Xboard) . "', "
                            . "sad_percentage = '" . addslashes($XIIperc) . "',"
                            . " sad_year_of_passing =  '$XIIyop' "
                            . "where sad_course_name = 'X' and sad_student_id = " . (int) $student_id;
                    $result3 = mysqli_query($con, $query3);
                    if ($result3) {
                        //                                     echo "Data updated";
                    } else {
                        mysqli_error($con);
                        //                                     echo "no run";
                    }

                    $query4 = "UPDATE student_acedemic_details "
                            . "SET sad_board = '" . addslashes($XIIboard) . "', "
                            . "sad_percentage = '" . addslashes($XIIperc) . "',"
                            . " sad_year_of_passing =  '$XIIyop' "
                            . "where sad_course_name = 'XII' and sad_student_id = " . (int) $student_id;
                    $result4 = mysqli_query($con, $query4);
                    if ($result4) {
                        //                                     echo "Data updated";
                    } else {
                        mysqli_error($con);
                        //                                     echo "no run";
                    }
                } else {
                    // Inserting the student details
//                    echo "DATA inserted";
                    $unregister+=1;
//                    echo $date1;
                    $query5 = "INSERT INTO student_details ( sd_first_name, sd_last_name, sd_email, sd_phone, sd_gender, sd_address, sd_city, sd_zip_code,sd_state, sd_country, sd_hobbies,sd_applied_course,sd_dob)
                                    VALUES ('$first_name', '$last_name', '$email', '$contact_no', '$gender', '$address_line1','$city','$pincode','$state','$country', '$hobbies','$course','$date1');";
                    $result5 = mysqli_query($con, $query5);
                    if ($result5) {
                        echo "Data inserted";
                    } else {
                        echo mysqli_error($con);
                    }
                    $student_id = mysqli_insert_id($con);
                    $student[] = array($student_id, $first_name, $last_name, $course, $email, $address_line1, $date, $gender);
                    echo $student_id . "<br>";
//                     Inserting academic details of 10th class.
                    $query6 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                                               VALUES ( $student_id,'X', '$Xboard','$Xperc', '$Xyop');";
                    //        $student_academic = mysqli_query($con,$query4);
                    if (mysqli_query($con, $query6)) {
                        //echo "New record created successfully";
                    } else {
                        echo "Error: " . $query6 . "<br>" . mysqli_error($con);
                    }
                    $query7 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                                               VALUES ( $student_id,'X', '$XIIboard','$XIIperc', '$XIIyop');";
                    //        $student_academic = mysqli_query($con,$query4);
                    if (mysqli_query($con, $query7)) {
                        //echo "New record created successfully";
                    } else {
                        echo "Error: " . $query7 . "<br>" . mysqli_error($con);
                    }
                }
//                }
            }
        }
    }

    }
}

?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">Student Data</h1>
		<div class="save-data">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6">
					<div class="student-count">
						<p><span>Total Students: </span><?php echo $register+$unregister;?></p>
						<p><span>Registered Students: </span><?php echo $register;?></p>
						<p><span>Unregister Students: </span><?php echo $unregister;?></p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6">
					<form  method="post" action="" enctype="multipart/form-data"          >
						<div class="form-group">
							<label>Upload File</label>
							<div class="box">
								 <label for="upload">Upload CSV file</label>
                                                                    <input name="the_file" type="file" id="fname" name="upload"><br>
                                                                    <!--<label for="file-1"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg> <span>Choose a file&hellip;</span></label>-->
                                                                 <input type="submit" id="lname" name="sub">
                                                                 <div><font color="#f00000" size="2px"><?php if(isset($errors) && count($errors)!=0) {echo "Please remove the error";} ?></font></div>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="table-responsive">
                    <?php if(isset($errors_final) && empty($errors_final)  && $table > 0){ ?>       
			<table class="user-detail">			
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Student Id</th>
						<th>Student</th>
						<th>Course</th>
						<th>Email id</th>
						<th>Qualification</th>
					</tr>
				</thead>
				<tbody>
					
                                            <?php   
                                            $count=1;
//                                            print_r($student);
                                            foreach($student as $key => $data){
                                            
                                            ?>
                                            <tr>    
						<td><?php echo $count;?></td>
						<td><?php echo $data[0];?></td>
						<td>
							<div class="image">
								<img src="" class="img-responsive"/>
							</div>
							<h4 class="user-name"><?php echo $data[1]." " .$data[2];?></h4>
							<h5 class="user-gender"><?php echo $data[7];?></h5>
							<h5 class="user-dob"><?php echo $data[6];?></h5>
							<div class="user-address">
								<p><?php echo $data[5];?> </p>
							</div>
						</td>
						<td><?php echo $data[3];?></td>
						<td><?php echo $data[4];?></td>
						<td>XII passout</td>
                                            </tr>   
                                            <?php 
                                                $count+=1;
                                             }
                                            
                                            
                                            
                                            
                                            ?>
					
				</tbody>
			</table>
                       <?php 
                       
                        }else{
                            foreach($errors_final as $key => $values){
                                foreach($values as $key1 => $values1){?>
                                 <div><font color="#f00000" size="2px"><?php echo "Row ".$key." ". $values1; ?></font></div>
                            
                            <?php     
                                }
                            }
                        }
                       ?>    
			</div>
						
		</div>
	</div>
</div>	
<?php include 'footer.php'; ?>
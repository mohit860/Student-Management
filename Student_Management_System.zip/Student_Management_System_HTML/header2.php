<!DOCTYPE html>
<?php
 require_once('header1.php');
 
// echo $_SESSION['name'];
// if (isset($_SESSION['sd_image'])) { echo "uploads/image/".$_SESSION['sd_email'];} 
?>
<html lang="en">
<head>
  <title>Student Management System</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/component.css">
  <link rel="stylesheet" href="css/bootstrap-datepicker3.css">
  
  
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-3">
					<div class="logo">
						<img src="images/logo.png"/>
					</div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-9">
					<div class="user-account">
						<ul>
							<li>
                                                               
  
                                                                <span class="user-welcome"><?php if (isset($_SESSION['sd_email'])) { echo "Welcome  ".$_SESSION['sd_first_name']." ". $_SESSION['sd_last_name'];} elseif(isset($_SESSION['name'])){echo $_SESSION['name'];}?></span>
                                                                <img class="account-pic" src="<?php if (isset($_SESSION['sd_image'])) { echo "uploads/image/".$_SESSION['sd_image'];} else {echo "images/user.png";}?>"/>
							</li>
							<li>
                                                            <a href="logout.php" class="btn btn-green btn-logout"><i class="fa fa-sign-out"></i> Log Out</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			
			
		</div>
	</header>
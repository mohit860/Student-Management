<?php
include '/lib/PHPMailer/PHPMailerAutoload.php';
require_once ('includes/config.php');
function send_mail($to,$subject,$body){
    // send email
    //Load composer's autoloader
    $mail = new PHPMailer;
    try {
        //Server settings
        $mail->isSMTP();                                      // Set mailer to use SMTP
//        $mail->Host = 'smtp.mailgun.org';  // Specify main and backup SMTP servers
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = user_name;                 // SMTP username
        $mail->Password = password;                           // SMTP password
        $mail->Port = 25;                                    // TCP port to connect to
//        $mail->SMTPDebug = true;
        //Recipients
        $mail->setFrom('ateotia@velsof.com', 'VELOCITY TEST MAIL');
        $mail->addAddress($to);     // Add a recipient
        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();
//        echo 'Message has been sent';
    } catch (Exception $e) {
//        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
}
?>
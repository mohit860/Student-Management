<?php


function session_store($email,$password,$first_name, $last_name,$address, $course, $date, $gender, $student_id, $sd_image){

       $_SESSION['sd_email'] = $email;
       $_SESSION['sd_password'] = $password;
       $_SESSION['sd_first_name'] =$first_name;
       $_SESSION['sd_last_name'] = $last_name;
       $_SESSION['sd_address']  = $address;
       $_SESSION['sd_course'] = $course;
       $_SESSION['sd_date'] =  $date;
       $_SESSION['sd_gender'] = $gender;
       $_SESSION['sd_student_id'] = $student_id;
       $_SESSION['sd_image'] = $sd_image;
       
    

    
}
?>

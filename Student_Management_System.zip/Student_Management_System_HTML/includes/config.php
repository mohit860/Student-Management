<?php
define("DAY","day25");
define("ROOT_DIR","C:/wamp64/www/".DAY."/Student_Management_System_HTML/");
define("FILE_PATH",ROOT_DIR."uploads");
define("URL","localhost/".DAY. "/Student_Management_System_HTML/");
define("user_name","mohitsingh17248@gmail.com");
define("password","mohit@8605989");
define("CLIENT_ID","867921963329-rgaioqnqhbeg91i1sdcr5rujbfvm5sbc.apps.googleusercontent.com");
define("CLIENT_SECRET","KK9dhy2Qm61V7TShXuPoYfv3");
define("REDIRECT_URI","http://localhost/day16/Student_Management_System_HTML/login.php");






?>
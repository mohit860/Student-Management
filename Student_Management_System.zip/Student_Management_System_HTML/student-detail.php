<?php include 'header2.php'; ?>
<?php

if (!isset($_SESSION['sd_email'])) {
    header("Location: login.php");
//    echo $_SESSION['sd_email'];
}
$student_id = "";
$first_name = "";
$last_name = "";
$date = "";
$email = "";
$gender = "";
$address_line1 = "";
$course = "";
$sd_image = "";
if (isset($_GET['action']) && $_GET['action'] == 'View'){
    if(!empty($_GET['sid'])){
         // To find details of students.
        $student_id = $_GET['sid'];
        $query1 = "Select * from student_details where sd_student_id = ".(int)$_GET['sid'];
        $result = mysqli_query($con, $query1);
//        echo mysqli_num_rows($result);
        if ($result) {
            $row = mysqli_fetch_assoc($result);  
            $first_name = $row['sd_first_name'];
            $last_name = $row['sd_last_name'];
            $date = $row['sd_dob'];
            $email = $row['sd_email'];
            $gender = ucfirst($row['sd_gender']);
            $address_line1 = $row['sd_address'];
            $course = $row['sd_applied_course'];
            $sd_image = $row['sd_image'];

        }
        else{
            echo mysqli_error($con);
        }
//        echo $course;
    }
}
?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">Student Detail</h1>
		
		<div class="row">
			<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
				<div class="profile-pic viewimage">
					<img src="<?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo "uploads/image/".$sd_image;} else{ echo "images/user.png";}?>"class="img-responsive"/>					
				</div>	
			</div>
			<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
			<div class="user-detail-view">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Student Id:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $student_id;} else{echo $_SESSION['sd_student_id'];}?></span>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Name:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $first_name." ".$last_name;} else{echo $_SESSION['sd_first_name']." ". $_SESSION['sd_last_name'];}?></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
						<div class="user-data full-width">
							<span class="grey">Address:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $address_line1;} else{echo $_SESSION['sd_address'];}?></span>
						</div>
					</div>
				</div>	
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Course:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $course;} else{ echo $_SESSION['sd_course'];}?></span>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Date of Birth:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $date;} else{echo $_SESSION['sd_date'];}?></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Gender:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $gender;} else{echo $_SESSION['sd_gender'];}?></span>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="user-data">
							<span class="grey">Email:</span>
                                                        <span class="blue"><?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $email;} else{echo $_SESSION['sd_email'];}?></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
						<div class="user-data">
							<span class="grey">Qualification:</span>
							<span class="blue">XII Passout</span>
						</div>
					</div>
				</div>	
				<div class="print-actions">
					<div class="col-lg-12 col-md-12 col-sm-12">
						<a href="index.php?sid=<?php if (isset($_GET['action']) && $_GET['action'] == 'View'){ echo $_GET['sid'];} ?>&action=Edit" class="btn btn-green"><i class="fa fa-edit"></i> Edit</a>
						<a href="#" class="btn btn-orange"><i class="fa fa-print"></i> Print</a>
					</div>
				</div>
				
				
			</div>
		</div>
		</div>
	</div>
</div>	
<?php include 'footer.php'; ?>
<form  method="post" action="" enctype="multipart/form-data">
  <label for="upload">Upload CSV file</label>
  <input name="the_file" type="file" id="fname" name="upload"><br>
  <label for="sub">Submit     </label>
  <input type="submit" id="lname" name="sub">
</form>

<?php

/*
 * File Name- index.php
 * Date- 1-August-2021
 * Author- Mohit
 * Purpose- To import the csv file..
 */
    require_once 'includes/config.php';
    include 'header1.php';
//    print_r($_FILES);
    
    function check_date($date, $month, $year) {
    if($year<1950 && $year>2021){
        return false;
    }
    
    // block to check conditions for non-leap year  
    if ($year % 4 != 0) {   // checking for a non-leap year
        if ($month == 02) {  // checking for february
            if ($date >= 29 || $date <= 0) { // checking for valid dates in month of february of a non - leap year 
                return FALSE;
            } else {
                return TRUE;
            }
        }
        if ($month != 02) {
            switch ($month) {
                case '01':  // January
                case '03':// March
                case '05':// May
                case '07':// July
                case '08':// august
                case '10'://October
                case '12':// December 
                    if ($date <= 0 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11':// November
                    if ($date <= 0 || $date > 30) {  //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default : echo "month is" . $month;
            }
        }
    }

    // Block to check conditions for leap year -------------------------- 
    if ($year % 4 == 0 || $year % 400 == 0) {  // Checking for a leap year
        // check for february ---------------------------
        if ($month == 02) {
            if ($date > 29 || $date <= 00) {
                // Checking for valid dates in month of february
                return FALSE; //false
            } else {
                // return true
                return TRUE;
            }
        }
        // checking for other months------------------------
        if ($month != 02) {
            switch ($month) {
                case '01' :// January
                case '03' :// March
                case '05' :// May
                case '07' :// July
                case '08' :// August
                case '10' :// October
                case '12' :// December 
                    if ($date <= 00 || $date > 31) { // checking dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                case '04' :// April
                case '06' :// June
                case '09' :// September
                case '11' :// November
                    if ($date <= 00 || $date > 30) {   //checking for dates that cannot occur in these months
                        return false;
                    } else {
                        return true;
                    }
                    break;
                default :
            }
        }
        // check for leap year ended here----------------------------------------
    }
}

    
    
    
    if(isset($_FILES['the_file']['name']) && !empty($_FILES['the_file']['name'])){
//               echo 1;
            $uploadDirectory = FILE_PATH."/csv/";
            $fileExtensionAllowed = ['csv'];
            $file_name = $_FILES['the_file']['name'];
            $file_size = $_FILES['the_file']['size'];
            $file_type = $_FILES['the_file']['type'];
            $fileTmpName = $_FILES['the_file']['tmp_name'];
            $file_name_time = time().$file_name;
            $file_name_break = explode('.',$file_name);
            $file_end = $file_name_break[1];
            $uploadPath = $uploadDirectory . basename($file_name_time);
            $didupload = move_uploaded_file($fileTmpName, $uploadPath);
            $file_name;
            $file = fopen("$file_name", "r");
//            print_r(fgetcsv($file));
            $flag =0;
//             
            while(($data = fgetcsv($file, 1000, ",")) !== FALSE){
                    if($data[0]=='sd_student_id'){

                    }
                    else{
                        $first_name = $data[1];
                        $last_name =  $data[2];
                        $date =  $data[3];
                        $email =  $data[4];
//                        $password =  $data[];
//                        $confirm_password =  $data[1];
                        $contact_no =  $data[5];
                        $gender =  $data[6];
                        $address_line1 =  $data[7];
                        $city =  $data[8];
                        $pincode =  $data[9];
                        $state =  $data[10];
                        $country =  $data[11];
                        $hobbies =  $data[12];
                        $course =  $data[13];
                        $Xboard =  $data[14];
                        $Xperc =  $data[15];
                        $Xyop =  $data[16];
                        $XIIboard =  $data[17];
                        $XIIperc =  $data[18];
                        $XIIyop =  $data[19];
                        $contact_no =  $data[20]; 
                        $errors = array();
                        if (empty($first_name)) {
                            $errors[0] = "Error: Please enter your first name";
                        } elseif (!ctype_alpha($first_name)) {
                            $errors[0] = "Please enter only alphabets";
                        }

                        if (empty($last_name)) {
                            $errors[1] = "Error: Please enter your last name";
                        } elseif (!ctype_alpha($last_name)) {
                            $errors[1] = "Please enter only alphabets";
                        }
                        $date_explode = explode('/', $date);
                            if(isset($date_explode[0])) {
                                    $day = $date_explode[0];
                            } else {
                                    $day = '';
                            }

                            if(isset($date_explode[1])) {
                                    $month = $date_explode[1];
                            } else {
                                    $month = '';
                            }

                            if(isset($date_explode[2])) {
                                    $year = $date_explode[2];
                            } else {
                                    $year = '';
                            }
                        $arr = array($year,$month,$day);
                        $date1 = implode("-",$arr);
                    //    echo $date1;
                        if (empty($date)) {
                            $errors[2] = "Please Enter Date-of-birth";
                        } elseif (!check_date($day,$month,$year)) {
                            $errors[2] = "Please enter a valid date-of-birth";
                        }

                        if (empty($email)) {
                            $errors[3] = "Please enter your email";
                        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $errors[3] = "Invalid email format";
                        } else {

                            $query = "Select * from student_details where sd_email ='$email'";
                            $result = mysqli_query($con, $query);
                            $num =mysqli_num_rows($result);
                            if ($num > 0) {
                                $errors[3] = "This email id has already registered.";
                            }

                        }

//                        if(!isset($_GET['action']) ){
//                            if (empty($password)) {
//                                $errors[4] = "Please enter your password";
//                            }
//                            if (empty($confirm_password)) {
//                                $errors[5] = "Please re-enter your password";
//                            }else if($password != $confirm_password){
//                                $errors[5] = "Please enter the same password";
//                            }
//                        }
//                        else{
//                            if($password != $confirm_password){
//                                $errors[5] = "Please enter the same password";
//                            }
//                        }

                        if (empty($contact_no)) {
                            $errors[6] = "Please enter your mobile number";
                        } elseif (strlen($contact_no) != 10) {//strlen - it will return the length of string
                            $errors[6] = "Please enter a 10-digit mobile number";
                        } elseif (!ctype_digit($contact_no)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[6] = "Error : Please enter only numbers";
                        }

                        if (empty($address_line1)) {
                            $errors[7] = "Please enter the address";
                        }
                        if (empty($city)) {
                            $errors[8] = "Error: Please enter your city";//common function to recall error message from database
                        } elseif (!ctype_alpha($city)) {
                            $errors[8] = "Please enter only alphabets";
                        }
                        if (empty($pincode)) {
                            $errors[9] = "Please enter your pincode";
                        } elseif (!ctype_digit($pincode)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[9] = "Error : Please enter only numbers";
                        }
                        if (empty($state)) {
                            $errors[10] = "Error: Please enter your state";//common function to recall error message from database
                        } elseif (!ctype_alpha($state)) {
                            $errors[10] = "Please enter only alphabets";
                        }
                        if (empty($country)) {
                            $errors[11] = "Error: Please enter your country";//common function to recall error message from database
                        } 
                        if (empty($Xboard)) {
                            $errors[12] = "Error: Please enter your board name";
                        } elseif (!ctype_alpha($Xboard)) {
                            $errors[12] = "Please enter only alphabets";
                        }
                        if (empty($Xperc)) {
                            $errors[13] = "Please enter your board percentage";
                        } elseif (!ctype_digit($Xperc)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[13] = "Error : Please enter only numbers";
                        }elseif(strlen($Xperc )!=2){
                            $errors[13] = "Enter only two digit";
                        }
                        if (empty($Xyop)) {
                            $errors[14] = "Please enter your X year of passing";
                        } elseif (!ctype_digit($Xyop)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[14] = "Error : Please enter only numbers";
                        }elseif(strlen($Xyop )!=4){
                            $errors[14] = "Error: Please enter a valid year";
                        }
                        if (empty($XIIboard)) {
                            $errors[15] = "Error: Please enter your board name";
                        } elseif (!ctype_alpha($XIIboard)) {
                            $errors[15] = "Please enter only alphabets";
                        }
                        if (empty($XIIperc)) {
                            $errors[16] = "Please enter your XII board percentage";
                        } elseif (!ctype_digit($XIIperc)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[16] = "Error : Please enter only numbers";
                        }elseif(strlen($XIIperc )!=2){
                            $errors[16] = "Error: Please enter only two digit";
                        }
                        if (empty($XIIyop)) {
                            $errors[17] = "Please enter your year of passing";
                        } elseif (!ctype_digit($XIIyop)) {//ctype_digit - it will check if the string contains all integer digit or not
                            $errors[17] = "Error : Please enter only numbers";
                        }elseif(strlen($XIIyop )!=4){
                            $errors[17] = "Error: Please enter a valid year";
                        }
                        if (empty($hobbies)) {
                            $errors[18] = "Please select your hobbies";
                        }
                        if (empty($course)) {
                            $errors[19] = "Please select your course";
                        }
                        if (isset($hobbies['Others']) && empty($hobbies_text)) {
                            $errors[20] = "Please fill your other hobbies";
                        }
                        if (empty($gender)){

                            $error[21] = "Please select the gender";
                    //        echo $error[21];
                        }
                        
 
                        if (empty($errors)){
//                        echo $data[0];
        //                    echo "<br>";
                            $query1 = "select * "
                                . "from student_details "
                                . "where sd_student_id = "."$data[0]";
    //                         echo "<br>";
                             $result1 = mysqli_query($con, $query1);
                             if($result1){
                                 if(mysqli_num_rows($result1)>=1){

                                    // updating the data 

    //                                echo $data[3];
                                    $query2 = "UPDATE student_details "
                                             . "SET sd_first_name = '".addslashes($data[1])."', "
                                             . "sd_last_name = '".addslashes($data[2])."',"
                                             . " sd_email =  '$data[4]',"
                                             . "sd_phone = '$data[5]' ,"
                                             . "sd_gender = '$data[6]', "
                                            . "sd_address = '$data[7]', "
                                            . "sd_city = '$data[8]', "
                                            . "sd_zip_code = '$data[9]',"
                                            . "sd_state = '$data[10]',"
                                            . "sd_country = '$data[11]',"
                                            . "sd_hobbies= '$data[12]', "
                                            . "sd_applied_course = '$data[13]' "
                                             . "where sd_student_id = " . "$data[0]";
                                     $result2 = mysqli_query($con, $query2);
    //                                 echo mysqli_num_rows($result12);
                                     if($result2){
    //                                     echo "Data updated";
                                     }
                                     else{
                                         mysqli_error($con);
    //                                     echo "no run";
                                     }

                                     $query3 = "UPDATE student_acedemic_details "
                                             . "SET sad_board = '".addslashes($data[14])."', "
                                             . "sad_percentage = '".addslashes($data[15])."',"
                                             . " sad_year_of_passing =  '$data[16]' "

                                             . "where sad_course_name = 'X' and sad_student_id = " . "$data[0]";
                                    $result3 = mysqli_query($con, $query3);
                                    if($result3){
    //                                     echo "Data updated";
                                     }
                                     else{
                                         mysqli_error($con);
    //                                     echo "no run";
                                     }

                                     $query4 = "UPDATE student_acedemic_details "
                                             . "SET sad_board = '".addslashes($data[17])."', "
                                             . "sad_percentage = '".addslashes($data[18])."',"
                                             . " sad_year_of_passing =  '$data[19]' "

                                             . "where sad_course_name = 'XII' and sad_student_id = " . "$data[0]";
                                     $result4 = mysqli_query($con, $query4);
                                    if($result4){
    //                                     echo "Data updated";
                                     }
                                     else{
                                         mysqli_error($con);
    //                                     echo "no run";
                                     }


                                }else{
                                    // Inserting the student details
                                    $query5 = "INSERT INTO student_details (sd_student_id, sd_first_name, sd_last_name, sd_email, sd_phone, sd_gender, sd_address, sd_city, sd_zip_code,sd_state, sd_country, sd_hobbies,sd_applied_course)
                                    VALUES ($data[0],'$data[1]', '$data[2]', '$data[4]', '$data[5]', '$data[6]', '$data[7]','$data[8]','$data[9]','$data[10]','$data[11]', '$data[12]','$data[13]');";
                                     $result5 = mysqli_query($con, $query5);
                                     if($result5){
                                         echo "Data inserted";
                                     }
                                     else{
                                         echo mysqli_error($con);
                                     }

                                    // Inserting academic details of 10th class.

                                    $query6 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                                               VALUES ( $data[0],'X', '$data[14]','$data[15]', '$data[16]');";
                                     //        $student_academic = mysqli_query($con,$query4);
                                     if (mysqli_query($con, $query6)) {
                                         //echo "New record created successfully";
                                     } else {
                                         echo "Error: " . $query6 . "<br>" . mysqli_error($con);
                                     }
                                     $query7 = "INSERT INTO student_acedemic_details ( sad_student_id, sad_course_name, sad_board, sad_percentage, sad_year_of_passing)
                                               VALUES ( $data[0],'X', '$data[17]','$data[18]', '$data[19]');";
                                     //        $student_academic = mysqli_query($con,$query4);
                                     if (mysqli_query($con, $query7)) {
                                         //echo "New record created successfully";
                                     } else {
                                         echo "Error: " . $query7 . "<br>" . mysqli_error($con);
                                     }

                                }
                             }
                        }
                        else{
                            
                        }
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                     }

            }



    }
    
?>
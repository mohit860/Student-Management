<?php 

/*
 * File Name- login.php
 * Date- 30-July-2021
 * Author- Mohit
 * Purpose- Authentication page for user login.
 */




include 'header.php'; ?>
<?php require_once('header1.php'); ?>

<?php

// check whether the token is present is url and then check it is valid token or not.
$token = "";
if(isset($_GET['token'])){
    $token = $_GET['token'];
    $query2 = "select sd_token from student_details where sd_token = '$token'";
    $result2 = mysqli_query($con, $query2);
    if(mysqli_num_rows($result2)>0){
           

    }
    else{
        $_SESSION['expire'] = 'Your link has expired';
        header("Location:login.php");
//        echo 'link has expired.';
    }
   
    
}






$password ="";
$confirm_password = "";
$errors = array();
$student_id = "";
//if(isset($_SESSION['student_id']) && !empty($_SESSION['student_id'])){
//    $student_id = $_SESSION['student_id'];
//}
if (isset($_POST['submit']) && $_POST['submit'] == 'Submit') {

       $password = mysqli_real_escape_string($con,$_POST['email']);
       $confirm_password = mysqli_real_escape_string($con,$_POST['password']);
       $hash_password = md5($password);

       
       // find the student id using token number
       
       $query4 = "select sd_student_id from student_details where sd_token = '$token'";
       $result4 = mysqli_query($con, $query4);
       if($result4){
           while($row = mysqli_fetch_array($result4)){
               $student_id  = $row['sd_student_id'];
           }
       }
       else{
           echo $query4. mysqli_error($con);
       }
       echo $student_id;
       
       
       
       // check validation of the password
       
        if (empty($password)) {
            $errors[1] = "Please enter your password";
        }elseif(strlen($password)<6){
            $errors[1] = "Please enter password atleast length of 6.";
        }
        if (empty($confirm_password)) {
            $errors[2] = "Please re-enter your password";
        }else if($password != $confirm_password){
            $errors[2] = "Please enter the same password";
        }
        if(count($errors)==0){
            // update new password in the database.
            
             $query = "update student_details "
                    . "set sd_password = '$hash_password', sd_token = NULL where sd_student_id = ".(int)$student_id ;
            $result = mysqli_query($con, $query);
            if($result){
                
            }
            else{
                echo $query. " ". mysqli_error($con);
            }
            
            
            $_SESSION['reset_msg'] = 'Your password has been changed.';
            unset($_SESSION['message']);
            header("Location:login.php");
        }
//        print_r($errors);

}      



?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">RESET PASSWORD</h1>
                 
                 <?php if (count($errors)!=0) { ?>
                    <div style="text-align:center; color: #f00000;"><?php echo "please see the errors below"; ?></div>
                <?php } ?> 
		<div class="signup-content">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3">
							<form id="sample" method="post" action="">
								<div class="form-group">
									<label>Password <span class="color-danger">*</span></label>								
                                                                        <input type="password" id="email" name="email" class="form-control" value="<?php echo $password; ?>" data-rule-email="true"/>									
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors[1])) echo $errors[1]; ?></font></div>
                                                                </div>
								<div class="form-group">
									<label>Confirm Password <span class="color-danger">*</span></label>
									<input type="password" class="form-control" id="password" name="password" value="<?php echo $confirm_password; ?>" data-rule-passwd="true"/>
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors[2])) echo $errors[2]; ?></font></div>
								</div>	
								
								<div class="form-group">
									<input name = 'submit' type="submit" value="Submit" class="btn btn-green sign_in" >
								</div>								
							</form>
						</div>						
					</div>
				</div>
	</div>
</div>	
<?php include 'footer.php'; ?>
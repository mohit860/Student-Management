<?php
/* File Name = report.php
 * Author = Mohit
 * Date = 16-Aug-2021
 * purpose = To show the reports in different tabs.
 * 
 */
include 'header.php';
include 'header1.php';
?>
<div id="tabs">
    <ul>
    <li><a href="#tabs-1">Male/Female </a></li>
    <li><a href="#tabs-2">No of registration in last 30 days in each day</a></li>
    <li><a href="#tabs-3">No of registration in last 30 days in each day(Line and Bar Graph)</a></li>
    <li><a href="#tabs-4">Male/Female/No of registration in last 30 days in each day(Line and Bar Graph)</a></li>
  </ul>
    <div id="tabs-1">
        <div id="chartContainer1" style="height: 300px; width: 100%;"></div>
        <?php 
        
        // retrieve the data from database.
        $query = "select sd_gender,sd_date_added from student_details";
        $result = mysqli_query($con, $query);
        $male = 0;
        $female =0;
        $date = array(); // Date in which student are registered.
        if(mysqli_num_rows($result)>0){
            while ($row=  mysqli_fetch_array($result)){
                if($row['sd_gender']== 'male'){
                    $male++;
                }else{
                    $female++;
                }
                $temp_date = explode(" ", $row['sd_date_added']); // split the date added so we can get only date.
                $date[] = $temp_date[0];
            }
        }else{
            echo $query." ".mysqli_error($con);
        }
        ?>
    </div>
    
    <div id="tabs-2">
        <div id="chartContainer2" style="height: 300px; width: 100%;"></div>
        
        <?php
        // create an array of last 30 days.
        $last_30_days = array();
        for($i = 0; $i < 30; $i++){ 
            $last_30_days[] = date("Y-m-d", strtotime('-'. $i .' days'));
        }
         
        // count the number of registration at each date.
        $registration_no = array();
        foreach($last_30_days as $key => $value){
            $count = 0;
            foreach($date as $key1 => $value1){
                if($value == $value1){   // If the date match with database then increase the count.
                    $count++;
                }
            }
            $registration_no[$value] =$count;
        }

        ?>
        
    </div>
    
    <div id="tabs-3">
         <div id="chartContainer3" style="height: 300px; width: 100%;"></div>
    </div>
    <div id="tabs-4">
         <div id="chartContainer4" style="height: 300px; width: 100%;"></div>
         <?php
          $male_date = array();
          $female_date = array();
        
          foreach($last_30_days as $key => $value){
            $male_count = 0;
            $female_count = 0;
            $query1 = "select sd_gender,sd_date_added from student_details";
            $result1 = mysqli_query($con, $query1);
            if(mysqli_num_rows($result1)>0){
                while ($row=  mysqli_fetch_array($result1)){
                      $temp_date = explode(" ", $row['sd_date_added']); // split the date added so we can get only date.                     
                      if($value == $temp_date[0] && $row['sd_gender']=="male") {
                          $male_count++;
                      }
                      else if($value == $temp_date[0] && $row['sd_gender']=="female"){
                          $female_count++;
                      }
                }
            }else{
                echo $query." ".mysqli_error($con);
            }       
            $male_date[$value] = $male_count;
            $female_date[$value] = $female_count;
        
        }

         ?>
    </div>
    <br> <br> <br> <br> <br> <br>
    
</div>

<script type="text/javascript">
  $( function() {
      
    // Pie chart code
    var options = {
      title: {
              text: "Male Female Ratio"
      },
      data: [{
                      type: "pie",
                      startAngle: 45,
                      showInLegend: "true",
                      legendText: "{label}",
                      indexLabel: "{label} ({y})",
                      yValueFormatString:"#,##0.#"%"",
                      dataPoints: [
                              { label: "Male", y: <?php echo $male;?> },
                              { label: "Female", y: <?php echo $female;?> },

                      ]
      }]
      };
      
      // Bar graph code
        var options2 = {
            animationEnabled: true,
            title: {
                    text: "Last 30 days registration date wise"
            },
            axisY: {
		title: "No. of student registered for a particular date.",
		
            },
            axisX: {
                  
                     title: "Date",
                    gridThickness: 2
            },
                
            data: [{
                    type: "column", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
//                    name: "no of registration",
                    dataPoints: [
                        <?php foreach($registration_no as $key => $value){
                            $date_split = explode("-",$key);             
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php 
                        }?>                    
                          
                            ]
                    }]
        };
        
        // Bar graph and line graph in a single graph.
        var options3 = {
            animationEnabled: true,
            title: {
                    text: "Last 30 days registration date wise"
            },
            axisY: {
		title: "No. of student registered for a particular date.",
		
            },
            axisX: {
                  
                     title: "Date",
                    gridThickness: 2
            },
                
            data: [ // bar graph code
                    {
                    type: "column", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
                     name: "no of registration",
                    dataPoints: [
                        <?php foreach($registration_no as $key => $value){
                            $date_split = explode("-",$key);   
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php }?>
//                       
                          
                        ]
                    },
                    // line graph code
                    {
                     type: "line", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
                     name: "no of registration",
                    dataPoints: [
                        <?php foreach($registration_no as $key => $value){
                            $date_split = explode("-",$key); 
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php }?>
                    ]
                    }
        ]
        };
        var options4 = {
            animationEnabled: true,
            title: {
                    text: "Last 30 days registration date wise"
            },
            axisY: {
		title: "No. of student registered for a particular date.",
		
            },
            axisX: {
                  
                     title: "Date",
                    gridThickness: 2
            },
                
            data: [ // bar graph code
                    {
                    type: "column", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
                    name: "no of registration",
                    dataPoints: [
                        <?php foreach($registration_no as $key => $value){
                            $date_split = explode("-",$key);   
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php }?>
//                       
                          
                        ]
                    },
                    // Male bar graph code
                    {
                     type: "column", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
                    name: "male",
                    dataPoints: [
                        <?php foreach($male_date as $key => $value){
                            $date_split = explode("-",$key); 
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php }?>
                    ]
                    },
                    {
                     type: "column", //change it to line, area, bar, pie, etc
                    showInLegend: true,
                    xValueType: "dateTime",
                    name: "female",
                    dataPoints: [
                        <?php foreach($female_date as $key => $value){
                            $date_split = explode("-",$key); 
                        ?>
                            {  x: new Date( <?php echo $date_split[0];?>, <?php echo (int)$date_split[1]-1;?>, <?php echo $date_split[2];?>) , y: <?php echo $value;?> },
                        <?php }?>
                    ]
                    }
        ]
        };
       
    $( "#tabs" ).tabs({
        create: function (event, ui) {
		//Render Charts after tabs have been created.
		$("#chartContainer1").CanvasJSChart(options);	
		$("#chartContainer2").CanvasJSChart(options2);	
		$("#chartContainer3").CanvasJSChart(options3);	
		$("#chartContainer4").CanvasJSChart(options4);	
	},
	activate: function (event, ui) {
		//Updates the chart to its container size if it has changed.
		ui.newPanel.children().first().CanvasJSChart().render();
	}
    });
 
  } );
  </script>

<?php
include 'footer.php';
?>
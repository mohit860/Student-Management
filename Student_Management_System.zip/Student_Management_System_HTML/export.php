<?php

/*
 * File Name- index.php
 * Date- 1-August-2021
 * Author- Mohit
 * Purpose- To export the csv file..
 */

include 'header1.php';
$query = "select *"
        . "from student_details ORDER BY sd_student_id";
$result = mysqli_query($con, $query);
$output[] = array('Student_id', 'First_name', 'Last_name', 'DOB', 'Email','Phone','Gender','Address','City','Zip Code','State','Country','Hobbies','Course','X_board','X_percentage','X_POY','XII_board','XII_percentage','XII_POY');
if($result){
    while($row = mysqli_fetch_array($result)){
        $student_id = $row['sd_student_id'];
        $academic = array('XIIboard'=>'','XIIperc'=>'','XIIyop'=>'','Xboard'=>'','Xperc'=>'','Xyop'=>'');
        $query2 = "select * "
                . "from student_acedemic_details "
                . "where sad_student_id = ".(int)$student_id ;
     
        $result2 = mysqli_query($con, $query2);
        if(mysqli_num_rows($result2)>0){
               
            while ($row1 = mysqli_fetch_array($result2)){
                    
                   if($row1['sad_course_name']== 'XII'){
                        $academic['XIIboard'] = $row1['sad_board'];
                        $academic['XIIperc'] = $row1['sad_percentage'];
                        $academic['XIIyop'] = $row1['sad_year_of_passing'];

                    }
                    if ($row1['sad_course_name']== 'X'){
                       $academic['Xboard']= $row1['sad_board'];
                       $academic['Xperc'] = $row1['sad_percentage'];
                       $academic['Xyop'] = $row1['sad_year_of_passing'];
                    }
            }
            
        }

       $output[] = array($row['sd_student_id'], $row['sd_first_name'], $row['sd_last_name'], $row['sd_dob'], $row['sd_email'],$row['sd_phone'],$row['sd_gender'],$row['sd_address'],$row['sd_city'],$row['sd_zip_code'],$row['sd_state'],$row['sd_country'],$row['sd_hobbies'],$row['sd_applied_course'],$academic['Xboard'], $academic['Xperc'], $academic['Xyop'],$academic['XIIboard'],$academic['XIIperc'], $academic['XIIyop']);
    }

    $filename = "export.csv";
    $files = fopen($filename,"w");
    foreach ($output as $key=>$value){
         fputcsv($files,$value);
    }

    fclose($files);
    header('content-Desription: File Transfer');
    header('content-Disposition: attachment; filename=' . $filename);
    header('content-Type: application/csv;');
    readfile($filename);
    //delete
    unlink($filename);
    exit;
    
}







?>
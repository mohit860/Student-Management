<?php
//unset($_SESSION['sd_email']);
session_start();
session_destroy();
//require_once('includes/config.php');
//require_once 'vendor/autoload.php';
//  
//// init configuration
//  
//$clientID =CLIENT_ID;
//$clientSecret = CLIENT_SECRET;
//$redirectUri = REDIRECT_URI;
//$google_login = "";
//// create Client Request to access Google API
//$client = new Google_Client();
//$client->setClientId($clientID);
//$client->setClientSecret($clientSecret);
//$client->setRedirectUri($redirectUri);
//$client->addScope("email");
//$client->addScope("profile");
//$client->revokeToken();
header("Location:login.php");

?>
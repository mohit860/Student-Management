<?php 
/*
 * File Name- student-listing.php
 * Date- 30-July-2021
 * Author- Mohit
 * Purpose- To show the details of all students and there are functionality like delete, edit and view.
 */

include 'header2.php';
require_once 'includes/config.php';

?>
<?php
// if(isset($_SESSION['name'])){ echo $_SESSION['name'];};
//echo $_SESSION['sd_image'];
//unset($_SESSION['sd_email']);
if (!isset($_SESSION['sd_email'])) {
    header("Location: login.php");
}
$errors = array();

if (isset($_GET['action']) && $_GET['action'] == 'delete1'){
//    print_r($_GET);
//    echo ($_GET['sid']);
    if(!empty($_GET['sid'])){
        $sid = $_GET['sid'];
        $query3 = "DELETE FROM student_acedemic_details where sad_student_id = ".(int)$_GET['sid'];
        if(mysqli_query($con, $query3)){
            $_SESSION['success_message'] = "Student details deleted successfully";
            echo 'sucessfully deleted';
//            header("Location: student-listing.php");
            
        } else{
            echo mysqli_error($con);
            echo 'System could not delete student. Please try again.'.$query3;
        }
        $query2 = "DELETE FROM student_details where sd_student_id = ".(int)$sid;
        if(mysqli_query($con, $query2)){
            $_SESSION['success_message'] = "Student details deleted successfully";
            header("Location: student-listing.php");
            exit;
        } else{
            echo mysqli_error($con);
            echo 'System could not delete student. Please try again.'.$query2;
        }
    }else{
        echo 'Student Id is not present in the request.';
    }
}

//mysqli_close($con);
        
?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">Student Detail</h1>
		<div class="option-buttons">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-8">
                                <label href="#" class="btn btn-orange"><i class="fa fa-plus-circle"></i> Add Student <input type="file" name="add-file" id="add-file" class="inputfile" /></label>
                                
                                <a href="save-data.php">    <label href="import.php"class="btn btn-green"><i class="fa fa-plus-circle"></i> Import CSV </label></a>
                                <a href="export.php?file=export.csv">     <label href="#" class="btn btn-orange"><i class="fa fa-plus-circle"></i> Export CSV </label></a>                               
                        </div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="input-group" class="ui-widget">
                                    <form id="sample" method="get" action="">
                                        
                                        
                                        <span class="input-group-btn">
                                            <input id="tags" name="search" type="text" <?php ?>value="<?php if(isset($_GET['search'])){ echo $_GET['search'];}?>"class="form-control" placeholder="Search for...">
                                            <button  type="submit" class="btn btn-search btn-green" type="button" <i class="fa fa-search fa-fw"></i>Search</button>>
					</span>
                                        
                                    </form>    

					
					  
				</div>
			</div>
		</div>
			
			
		</div>
		<div class="table-responsive">
			<table class="user-detail">			
				<thead>
					<tr>
						<th><input type="checkbox" name="all-selected" value=""/></th>
						<th>Student Id</th>
						<th>Student</th>
						<th>Course</th>
						<th>Email id</th>
						<th>Qualification</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
                                    <?php
                                    $number_of_pages = 0;
                                    $page = 0;
                                    $search_condition = "";
                                    $search_condition1 = "";
                                    if(isset($_GET['search'])){
                                        if(!empty($_GET['search'])){
                                            $search_condition = "where sd_first_name = "."'".$_GET['search']."'"." or sd_email like "."'%".$_GET['search']."%'";
//                                            $search_condition1 = "where sd_first_name = "."'".$_GET['search']."'"." or sd_email like "."'%".$_GET['search']."%'"."limit $start_page, $limit";
                                            
                                        }
                                    }
                    
                                        $query5 = "select * "
                                                . "from student_details ".$search_condition ;       
                                        $result5 = mysqli_query($con, $query5); 
                                        $number_of_results = mysqli_num_rows($result5);
                                        $limit =3;
                                        $number_of_pages = ceil($number_of_results/$limit);
                                        if(!isset($_GET['page'])){
                                            $page = 1;
                                        } else{
                                            $page = $_GET['page'];
                                        }
                                        $start_page = ($page-1)*$limit;
                                        $query6 = "SELECT * FROM student_details ".$search_condition."limit $start_page, $limit";
                                        $result6 = mysqli_query($con, $query6);
                                        if ($result6) {
                                            while($row = mysqli_fetch_array($result6)) {?>
                                                  <tr>
                                                      <td><input type="checkbox" name="selected1" value=""/></td>
                                                      <td><?php echo $row['sd_student_id']; ?></td>
                                                      <td>
                                                              <div class="image">
                                                                  <img src="<?php if(!empty($row['sd_image'])){echo "uploads/image/".$row['sd_image'];} else { echo "images/user.png";}?>" class="img-responsive"/>
                                                              </div>
                                                              <h4 class="user-name"><?php echo $row['sd_first_name']." ".$row['sd_last_name']; ?></h4>
                                                              <h5 class="user-gender"><?php echo $row['sd_gender']; ?></h5>
                                                              <h5 class="user-dob"><?php echo $row['sd_dob']; ?></h5>
                                                              <div class="user-address">
                                                                      <p><?php echo $row['sd_address']; ?> </p>
                                                              </div>
                                                      </td>
                                                      <td><?php echo $row['sd_applied_course']; ?></td>
                                                      <td><?php echo $row['sd_email']; ?></td>
                                                      <td>XII passout</td>
                                                      <td><a href="" class="btn btn-green"><i class="fa fa-download"></i> Document</a>
                                                              <div class="user-actions">
                                                                      <a href="student-detail.php?sid=<?php echo $row['sd_student_id'];?>&action=View" class="btn btn-orange" title="View"><i class="fa fa-eye"></i> </a>
                                                                      <a href="student-listing.php?sid=<?php echo $row['sd_student_id'];?>&action=delete1" onclick="confirm('Are you sure to delete this student?')" class="btn btn-orange" title="Delete"><i class="fa fa-trash"></i> </a>
                                                                      <a href="index.php?sid=<?php echo $row['sd_student_id']; ?>&action=Edit" class="btn btn-orange" title="Edit"><i class="fa fa-pencil"></i> </a>
                                                              </div>
                                                      </td>
                                              </tr>


                                          <?php  }
                                          } else {
                                                  echo mysqli_error($con);

                                          }
//                                          
                                    
                                    
                                  ?>
                                    
                                    
                                    
					
				</tbody>
			</table>
		</div>
		<div class="pager-navigation">
        <ul class="pagination">
             <li ><a href="#">&laquo;</a></li>
            <?php
            for($i=1; $i<= $number_of_pages; $i++){?>
           
             <li class="<?php if(isset($_GET['search'])){ if($i==$page){echo 'active';}} elseif($i==$page){ echo 'active';}?>"><a href="student-listing.php?page=<?php echo $i; if(isset($_GET['search'])){ echo "&search=".$_GET['search'];} ?>&action=page"><?php echo $i; ?></a></li>
           
            <?php } ?>
            <li><a href="#">&raquo;</a></li>
        </ul>
    </div>
	</div>
</div>
<script>
    $( function() {
      var availableTags = []  //  This array elements will give the suggestion.
    //Retrieve the data from db 
    <?php 
    $query = "select sd_first_name,sd_email from student_details";
    $result = mysqli_query($con,$query);
    if(mysqli_num_rows($result)>0){
        while($row=  mysqli_fetch_array($result)){

        ?>
         availableTags.push("<?php echo $row['sd_first_name']; ?>");   // adding first name 
         availableTags.push("<?php echo $row['sd_email']; ?>");     // adding email address 
    <?php    
        }
    }
    else{
        echo $query." ".mysqli_error($con);
    }
    ?>
    
    $( "#tags" ).autocomplete({
      source: "availableTags",
      minLength: 2,
      select: function( event, ui ) {
        log( "Selected: " + ui.item.value + " aka " + ui.item.id );
      }
    });
   
  } );

</script>
<?php include 'footer.php'; ?>
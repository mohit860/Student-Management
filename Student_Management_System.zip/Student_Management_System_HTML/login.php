<?php 

/*
 * File Name- login.php
 * Date- 30-July-2021
 * Author- Mohit
 * Purpose- Authentication page for user login.
 */




 ?>
<?php require_once('header1.php'); ?>
<?php
 
require_once('includes/config.php');
require_once 'vendor/autoload.php';
require_once('includes/functions/session.php');
  
// init configuration
  
$clientID =CLIENT_ID;
$clientSecret = CLIENT_SECRET;
$redirectUri = REDIRECT_URI;
$google_login = "";
// create Client Request to access Google API

$client = new Google_Client();
$client->setClientId($clientID);
$client->setClientSecret($clientSecret);
$client->setRedirectUri($redirectUri);
$client->addScope("email");
$client->addScope("profile");

// authenticate code from Google OAuth Flow

if (isset($_GET['code'])) {
$token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
$client->setAccessToken($token['access_token']);

// get profile info
$google_oauth = new Google_Service_Oauth2($client);
$google_account_info = $google_oauth->userinfo->get();
    if($google_account_info->picture){
       $picture = $google_account_info->picture;
       $_SESSION['picture'] = $picture;
    }
    $email =  $google_account_info->email;
    $name1 =  $google_account_info->name;
    $query1  = "SELECT * from student_details where sd_email ='".addslashes($email)."'";
    $result1 = mysqli_query($con, $query1);
    
    // Store the value in session 
    
    if (mysqli_num_rows($result1) > 0) {
        $result1 = mysqli_fetch_array($result1);
        session_store($result1['sd_email'],$result1['sd_password'], $result1['sd_first_name'], $result1['sd_first_name'], $result1['sd_address'],$result1['sd_applied_course'],  $result1['sd_dob'],$result1['sd_gender'],$result1['sd_student_id'],$result1['sd_image']);       
       header("Location: student-listing.php");
       
    }else{
        $_SESSION['expire'] ="This is email id is not registered.";
        header("Location: login.php");
        
    } 
    


} else {
$google_login = "<a href='".$client->createAuthUrl()."'>Google Login</a>";


}
$email ="";
$password = "";
if (isset($_POST['submit']) && $_POST['submit'] == 'Submit') {
       $email =  mysqli_real_escape_string($con,$_POST['email']);
       $password = mysqli_real_escape_string($con,$_POST['password']);
       $errors = array();
       
       // check the validation
       
       if (empty($email)) {
            $errors['email'] = "Please enter your email";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "Please enter valid email format";
        }
        if(empty($password)){
            $errors['password'] = "Please enter your password";
        }elseif(strlen($password)<6){
            $errors['password'] = "Please enter password atleast length of 6.";
        }
        $result =0;
        // check the authenctication
        
        if(count($errors)==0){
            $encrypt_password = md5($password);
            $query1  = "SELECT * from student_details where sd_email ='".addslashes($email)."' AND sd_password = '$encrypt_password'";
            $result1 = mysqli_query($con, $query1);
            if (mysqli_num_rows($result1) > 0) {
                $result1 = mysqli_fetch_array($result1);
                $result = 1;
                 session_store($result1['sd_email'],$result1['sd_password'], $result1['sd_first_name'], $result1['sd_first_name'], $result1['sd_address'],$result1['sd_applied_course'],  $result1['sd_dob'],$result1['sd_gender'],$result1['sd_student_id'],$result1['sd_image']);
                 if(isset($_POST['is_ajax']) && $_POST['is_ajax']==1){
                     
                 }else{
                     header("Location: student-listing.php");
                 }
            } else{
                $errors["common"] ="Please provide correct crendtials";
            }
        }
        
        else {

                $errors["common"] = 'You must provide valid email/password.';
        }
        if(isset($_POST['is_ajax']) && $_POST['is_ajax']==1){
            $response = array();
            if(count($errors)>0){
                $response['type'] = "error";
                $response["error"] = $errors;
                
            }else{
                  $response['type'] = "success";
            }
            
            echo json_encode($response);
            die;
        }
            
}      



include 'header.php';
?>
<div class="container">
	<div class="ManagementSystem">
		<h1 class="form-title">Log In</h1>
                <div style="text-align:center;" ><input name = 'submit' type="submit" value="Log In" id="login1" class="btn btn-green sign_in" ></div>
                 <?php if ( isset($result) and $result ==0) { ?>
                    <div style="text-align:center; color: #f00000;"><?php echo "please enter valid email/password"; ?></div>
                    
                <?php } ?> 
                <?php 
                    if(isset($_SESSION['message']) && !isset($_SESSION['reset_msg'])){?>
                    <div style="text-align:center; color:green;"><?php echo $_SESSION['message']; unset($_SESSION['message'])?></div>
                <?php    
                    }
                 ?>   
                <?php 
                    if(isset($_SESSION['reset_msg'])){?>
                    <div style="text-align:center; color:green;"><?php echo $_SESSION['reset_msg']; unset($_SESSION['reset_msg']) ?></div>
                <?php    
                    }
                 ?> 
                <?php 
                    if(isset($_SESSION['expire'])){?>
                    <div style="text-align:center; color:red;"><?php echo $_SESSION['expire']; unset($_SESSION['expire']) ?></div>
                <?php    
                    }
                 ?> 
                <div id="error" class="error" style="color:Red"></div>
		<div class="signup-content">
                                        
                                        <div id="dialog" title="Login">
                                            <div class="row" id="login_detail" style="display:none;">
						<div class="col-lg-6 col-md-6 col-sm-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3">
							<form id="sample" method="post" action="">
                                                            <div class="error" style="color:red; text-align:center;" id="common_error"></div>
								<div class="form-group">
									<label>Email Address <span class="color-danger">*</span></label>								
									<input type="text" id="email" name="email" class="form-control" value="<?php echo $email; ?>" data-rule-email="true"/>									
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors['email'])) echo $errors['email']; ?></font></div>
                                                                        <div class="error" style="color:red" id="email_error"></div>
                                                                </div>
								<div class="form-group">
									<label>Password <span class="color-danger">*</span></label>
									<input type="password" class="form-control" id="password" name="password" value="<?php echo $password; ?>" data-rule-passwd="true"/>
                                                                        <div><font color="#f00000" size="2px"><?php if(isset($errors['password'])) echo $errors['password']; ?></font></div>
                                                                        <div class="error" style="color:red" id="password_error"></div>
                                                                        
								</div>	
                                                          
								<div class="form-group" style="display: inline-block;   width: 100%;">
									<div class="rememberme_block pull-left">
										<label for="rememberme">
											<input type="checkbox" name="rememberme" id="rememberme" class="" value="yes"> Remember me</label>
									</div>
                                                                       
                                                                    <div class="forgot_block pull-right"><a href="forgot_password.php">Forgot Password?</a></div>
								</div>
								<div class="form-group">
                                                                        <input type="hidden" name="is_ajax" value="0" id="is_ajax">
                                                                        <input type="hidden" name="submit" value="Submit" >
                                                                        
									<input name = 'submit' type="submit" value="Submit" id="login" class="btn btn-green sign_in" >
                                                                         
                                                                         
								</div>
                                                                <div class="form-group">
									<?php
                                                                        echo $google_login;
                                                                        ?>
								</div>
                                                                
							</form>
                                                        
						</div>						
					</div>
                                        </div>
				</div>
	</div>
</div>	
<script>
    // This function is used to hide the details of login when the page reload. // This is alternative method.
//    function login_hide(){
//        $("#login_detail").hide()
//    }
    $(document).ready(function() {
//                login_hide()
                $("#login1").on("click", function(e) {
                    e.preventDefault();
                   $( "#dialog" ).dialog();
                   $("#login_detail").show() aja

                      
                });
                       
		$("#login").on("click", function(e) {
                        e.preventDefault();
			$(".error").html("");
                        $("#is_ajax").val("1");
			$.ajax({
				url: 'login.php',
				data: $("#sample").serialize(),
				type: 'post',
				dataType: 'json',
				success: function(data) {
//                                        
					if(data.type == "success") {
                                            window.location.href = 'student-listing.php'; // This part help to redirect to another page
//                                            window.location.replace("student-listing.php"); // This another way to redirect to anothe page
					} else if(data.type == "error") {
                                                $.each(data.error, function(index,value){
                                                   
                                                    $("#"+index+"_error").html(value);
                                                });
                                                
//						
						
					}
				}
			})
			return false;
		})
	
    });
    
</script>
<?php include 'footer.php'; ?>